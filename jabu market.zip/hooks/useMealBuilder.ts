// hooks/useMealBuilder.ts
// Manages the full meal builder state with dynamic category steps

import { useState, useEffect, useCallback, useMemo } from 'react';
import type {
  MenuCategoryInfo,
  VendorMenuItem,
  BuilderState,
  CategoryState,
  VendorMenu,
} from '@/types/meal-builder';
import {
  defaultCategoryState,
  buildOrderPayload,
  isOptionalStep,
  BUILDER_INITIAL_STATE,
} from '@/types/meal-builder';

type Status = 'idle' | 'loading' | 'ready' | 'sending' | 'sent' | 'error';

type UseMealBuilderOptions = {
  vendorId: string;
  onOrderSent?: (result: { order_id: string; conversation_id: string }) => void;
  initialLines?: import('@/types/meal-builder').OrderLine[];
};

const DRAFT_TTL = 30 * 60 * 1000; // 30 minutes

function draftKey(vendorId: string) {
  return `meal-draft-${vendorId}`;
}

export function useMealBuilder({ vendorId, onOrderSent, initialLines }: UseMealBuilderOptions) {
  const [categories, setCategories] = useState<MenuCategoryInfo[]>([]);
  const [itemsById, setItemsById] = useState<Record<string, VendorMenuItem>>({});
  const [status, setStatus] = useState<Status>('idle');
  const [error, setError] = useState<string | null>(null);
  const [state, setState] = useState<BuilderState>(BUILDER_INITIAL_STATE);
  const [step, setStep] = useState<string>('');
  const [draftRestored, setDraftRestored] = useState(false);
  // true when vendor flips accepts_orders off while builder is open
  const [vendorClosed, setVendorClosed] = useState(false);

  // All step keys in order: category names → fulfillment → review
  const steps = useMemo(
    () => [...categories.map((c) => c.name), 'fulfillment', 'review'],
    [categories]
  );

  const stepIndex = steps.indexOf(step);

  // Start on first category once loaded
  useEffect(() => {
    if (categories.length > 0 && step === '') {
      setStep(categories[0].name);
    }
  }, [categories, step]);

  // Subscribe to accepts_orders changes via Supabase Realtime.
  // If the vendor closes while the builder is open, surface a banner immediately
  // and block submission — the student's selections are preserved in draft.
  useEffect(() => {
    if (!vendorId) return;

    // Dynamic import keeps supabase client out of the hook's direct deps
    let cleanup: (() => void) | undefined;
    import('@/lib/supabase').then(({ supabase }) => {
      // Read current state first so we don't false-alarm on stale page-load data
      supabase
        .from('vendors')
        .select('accepts_orders')
        .eq('id', vendorId)
        .single()
        .then(({ data }) => {
          if (data && !data.accepts_orders) setVendorClosed(true);
        });

      const channel = supabase
        .channel(`meal-builder-vendor:${vendorId}`)
        .on(
          'postgres_changes',
          { event: 'UPDATE', schema: 'public', table: 'vendors', filter: `id=eq.${vendorId}` },
          (payload) => {
            const row = payload.new as { accepts_orders?: boolean };
            if (typeof row.accepts_orders === 'boolean') {
              setVendorClosed(!row.accepts_orders);
            }
          }
        )
        .subscribe();

      cleanup = () => { supabase.removeChannel(channel); };
    });

    return () => { cleanup?.(); };
  }, [vendorId]);

  // Fetch menu from API
  useEffect(() => {
    if (!vendorId) return;
    setStatus('loading');
    fetch(`/api/vendors/${vendorId}/menu`)
      .then((r) => r.json())
      .then((json) => {
        if (!json.ok) throw new Error(json.error ?? 'Failed to load menu');
        const cats: MenuCategoryInfo[] = json.categories ?? [];
        if (cats.length === 0) throw new Error('This vendor has no menu items yet');
        setCategories(cats);
        const map: Record<string, VendorMenuItem> = {};
        for (const cat of cats) for (const item of cat.items) map[item.id] = item;
        setItemsById(map);
        const initCats: Record<string, CategoryState> = {};
        for (const cat of cats) initCats[cat.name] = defaultCategoryState();

        // ── Prefill from a previous order (reorder flow) ──────────────────────
        // Takes priority over draft restore. Rebuilds CategoryState from OrderLines
        // by matching item_id to the loaded menu categories.
        if (initialLines && initialLines.length > 0) {
          const prefillCats: Record<string, CategoryState> = { ...initCats };

          for (const line of initialLines) {
            // Find which category this item belongs to in the current menu
            const cat = cats.find((c) => c.items.some((i) => i.id === line.item_id));
            if (!cat) continue; // item no longer exists — skip silently
            const cs = prefillCats[cat.name] ?? defaultCategoryState();

            if (cat.stepType === 'required_single') {
              prefillCats[cat.name] = { ...cs, selectedId: line.item_id, skipped: false };
            } else if (cat.stepType === 'required_single_qty') {
              prefillCats[cat.name] = { ...cs, selectedId: line.item_id, selectedQty: line.qty, skipped: false };
            } else if (cat.stepType === 'required_multi_qty') {
              prefillCats[cat.name] = {
                ...cs,
                quantities: { ...cs.quantities, [line.item_id]: line.qty },
                skipped: false,
              };
            } else if (cat.stepType === 'optional_single') {
              prefillCats[cat.name] = { ...cs, selectedId: line.item_id, skipped: false };
            } else if (cat.stepType === 'optional_multi') {
              const ids = cs.selectedIds.includes(line.item_id)
                ? cs.selectedIds
                : [...cs.selectedIds, line.item_id];
              prefillCats[cat.name] = { ...cs, selectedIds: ids, skipped: false };
            }
          }

          setState((prev) => ({ ...prev, categories: prefillCats }));
          setStatus('ready');
          return; // skip draft restore
        }

        // Try to restore a saved draft before setting state
        let restoredStep = '';
        try {
          const raw = localStorage.getItem(draftKey(vendorId));
          if (raw) {
            const draft = JSON.parse(raw);
            const loadedSteps = [...cats.map((c) => c.name), 'fulfillment', 'review'];
            const draftCatKeys = Object.keys(draft.state?.categories ?? {});
            const compatible =
              draft.vendorId === vendorId &&
              Date.now() - draft.savedAt < DRAFT_TTL &&
              draftCatKeys.length > 0 &&
              draftCatKeys.every((k: string) => cats.some((c) => c.name === k)) &&
              loadedSteps.includes(draft.step);

            if (compatible) {
              setState({
                categories: { ...initCats, ...draft.state.categories },
                orderType: draft.state.orderType ?? 'pickup',
                deliveryAddress: draft.state.deliveryAddress ?? '',
                pickupNote: draft.state.pickupNote ?? '',
              });
              restoredStep = draft.step;
              setDraftRestored(true);
            }
          }
        } catch { /* localStorage unavailable or malformed — start fresh */ }

        if (!restoredStep) {
          setState((prev) => ({ ...prev, categories: initCats }));
        }
        setStatus('ready');
        if (restoredStep) setStep(restoredStep);
      })
      .catch((e) => {
        setError(e.message);
        setStatus('error');
      });
  }, [vendorId]);

  // Persist draft to localStorage on every selection change
  useEffect(() => {
    if (status !== 'ready' || !step) return;
    try {
      localStorage.setItem(draftKey(vendorId), JSON.stringify({
        vendorId, savedAt: Date.now(), state, step,
      }));
    } catch { /* ignore write failures */ }
  }, [state, step, status, vendorId]);

  // Clear draft when order is successfully placed
  useEffect(() => {
    if (status === 'sent') {
      try { localStorage.removeItem(draftKey(vendorId)); } catch {}
    }
  }, [status, vendorId]);

  const discardDraft = useCallback(() => {
    try { localStorage.removeItem(draftKey(vendorId)); } catch {}
    const initCats: Record<string, CategoryState> = {};
    for (const cat of categories) initCats[cat.name] = defaultCategoryState();
    setState({ ...BUILDER_INITIAL_STATE, categories: initCats });
    setStep(categories[0]?.name ?? '');
    setStatus('ready');
    setError(null);
    setDraftRestored(false);
  }, [vendorId, categories]);

  // Running total
  const total = useMemo(() => {
    let t = 0;
    for (const cat of categories) {
      const cs = state.categories[cat.name];
      if (!cs || cs.skipped) continue;
      if (cat.stepType === 'required_single') {
        if (cs.selectedId && itemsById[cs.selectedId]) t += itemsById[cs.selectedId].price_per_unit;
      } else if (cat.stepType === 'required_single_qty') {
        if (cs.selectedId && itemsById[cs.selectedId]) t += itemsById[cs.selectedId].price_per_unit * Math.max(1, cs.selectedQty);
      } else if (cat.stepType === 'required_multi_qty') {
        for (const [id, qty] of Object.entries(cs.quantities)) {
          if (qty > 0 && itemsById[id]) t += itemsById[id].price_per_unit * qty;
        }
      } else if (cat.stepType === 'optional_single') {
        if (cs.selectedId && itemsById[cs.selectedId]) t += itemsById[cs.selectedId].price_per_unit;
      } else if (cat.stepType === 'optional_multi') {
        for (const id of cs.selectedIds) {
          if (itemsById[id]) t += itemsById[id].price_per_unit;
        }
      }
    }
    return t;
  }, [categories, state.categories, itemsById]);

  // Can the current step advance?
  const canAdvance = useMemo((): boolean => {
    if (step === 'fulfillment') {
      return state.orderType === 'pickup' || state.deliveryAddress.trim().length > 0;
    }
    if (step === 'review') return true;

    const cat = categories.find((c) => c.name === step);
    if (!cat) return false;
    const cs = state.categories[step];
    if (!cs) return false;

    if (isOptionalStep(cat.stepType)) {
      return cs.skipped || cs.selectedId !== null || cs.selectedIds.length > 0 || Object.values(cs.quantities).some((q) => q > 0);
    }
    switch (cat.stepType) {
      case 'required_single':     return cs.selectedId !== null;
      case 'required_single_qty': return cs.selectedId !== null;
      case 'required_multi_qty':  return Object.values(cs.quantities).some((q) => q > 0);
      default: return true;
    }
  }, [categories, step, state]);

  // Navigation
  const goNext = useCallback(() => {
    if (!canAdvance) return;
    const next = steps[stepIndex + 1];
    if (next) setStep(next);
  }, [canAdvance, steps, stepIndex]);

  const goBack = useCallback(() => {
    const prev = steps[stepIndex - 1];
    if (prev) setStep(prev);
  }, [steps, stepIndex]);

  const goToStep = useCallback((s: string) => {
    const idx = steps.indexOf(s);
    if (idx !== -1 && idx <= stepIndex) setStep(s);
  }, [steps, stepIndex]);

  // Category state updater
  const updateCat = useCallback((catName: string, updater: (cs: CategoryState) => CategoryState) => {
    setState((prev) => ({
      ...prev,
      categories: {
        ...prev.categories,
        [catName]: updater(prev.categories[catName] ?? defaultCategoryState()),
      },
    }));
  }, []);

  // Item selection helpers
  const selectSingle = useCallback((catName: string, itemId: string) =>
    updateCat(catName, (cs) => ({ ...cs, selectedId: itemId, skipped: false })), [updateCat]);

  const setSingleQty = useCallback((catName: string, qty: number) =>
    updateCat(catName, (cs) => ({ ...cs, selectedQty: Math.max(1, Math.min(10, qty)) })), [updateCat]);

  const setMultiQty = useCallback((catName: string, itemId: string, qty: number) =>
    updateCat(catName, (cs) => ({
      ...cs,
      quantities: { ...cs.quantities, [itemId]: Math.max(0, Math.min(10, qty)) },
    })), [updateCat]);

  const toggleMultiItem = useCallback((catName: string, itemId: string) =>
    updateCat(catName, (cs) => ({
      ...cs,
      selectedIds: cs.selectedIds.includes(itemId)
        ? cs.selectedIds.filter((id) => id !== itemId)
        : [...cs.selectedIds, itemId],
      skipped: false,
    })), [updateCat]);

  const skipCategory = useCallback((catName: string) =>
    updateCat(catName, (cs) => ({ ...cs, selectedId: null, selectedIds: [], quantities: {}, skipped: true })), [updateCat]);

  const setOrderType = useCallback((orderType: 'pickup' | 'delivery') =>
    setState((p) => ({ ...p, orderType })), []);

  const setDeliveryAddress = useCallback((deliveryAddress: string) =>
    setState((p) => ({ ...p, deliveryAddress })), []);

  const setPickupNote = useCallback((pickupNote: string) =>
    setState((p) => ({ ...p, pickupNote })), []);

  const reset = useCallback(() => {
    const initCats: Record<string, CategoryState> = {};
    for (const cat of categories) initCats[cat.name] = defaultCategoryState();
    setState({ ...BUILDER_INITIAL_STATE, categories: initCats });
    setStep(categories[0]?.name ?? '');
    setStatus('ready');
    setError(null);
  }, [categories]);

  // Submit order
  const submitOrder = useCallback(async () => {
    if (status === 'sending') return;
    if (vendorClosed) {
      setError('This vendor is not accepting orders right now.');
      return;
    }
    setStatus('sending');
    setError(null);

    const menu: VendorMenu = { categories, _itemsById: itemsById };
    const payload = buildOrderPayload(menu, state, vendorId);

    if (payload.total <= 0) {
      setError('Please select at least one item');
      setStatus('ready');
      return;
    }

    try {
      const res = await fetch('/api/orders/create', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          vendor_id: vendorId,
          order_payload: payload,
          pickup_note: state.pickupNote || undefined,
          order_type: state.orderType,
          delivery_address: state.orderType === 'delivery' ? state.deliveryAddress : null,
        }),
      });

      const json = await res.json();
      if (!res.ok || !json.ok) throw new Error(json.message ?? 'Failed to create order');

      setStatus('sent');
      onOrderSent?.({ order_id: json.order_id, conversation_id: json.conversation_id });
    } catch (e: any) {
      setError(e.message ?? 'Something went wrong');
      setStatus('error');
    }
  }, [categories, itemsById, state, vendorId, status, onOrderSent]);

  return {
    categories,
    itemsById,
    status,
    error,
    state,
    step,
    stepIndex,
    steps,
    total,
    canAdvance,
    // Navigation
    goNext,
    goBack,
    goToStep,
    reset,
    // Draft
    draftRestored,
    discardDraft,
    // Vendor status
    vendorClosed,
    // Mutations
    selectSingle,
    setSingleQty,
    setMultiQty,
    toggleMultiItem,
    skipCategory,
    setOrderType,
    setDeliveryAddress,
    setPickupNote,
    submitOrder,
  };
}