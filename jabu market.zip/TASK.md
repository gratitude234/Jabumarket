Read CLAUDE.md first. Then implement all of the following in order. These are Study Hub improvements. Do not modify any API routes, DB schema, or RLS policies unless explicitly told to. Preserve all existing TypeScript types and patterns.

---

## 1 — LEADERBOARD: Show the current user their own rank

File: app/study/leaderboard/page.tsx

This is a Server Component. It already fetches the leaderboard rows and the current user via createSupabaseServerClient().

Changes:
- After fetching the leaderboard rows, find the current user's row by matching user_id to the auth user's id
- Calculate the current user's rank (their position in the full sorted list, even if they're not in the top N displayed)
- In the render, add a "You" badge (text: "You") next to the current user's alias row if they appear in the visible list — use a small inline badge with bg-primary/10 text-primary rounded-full px-2 py-0.5 text-xs font-semibold
- If the current user is NOT in the visible top list, pin a separate "Your rank" row at the very bottom of the leaderboard table, visually separated with a border-t-2 border-dashed border-border. Show their alias, points, and rank number. Label it with a "You" badge.
- Add a summary line above the leaderboard table (below the scope tabs) showing: "Your rank: #N · X points" — use text-sm text-muted-foreground. If the user has no points yet, show "You haven't earned any points yet — answer a question to get started."
- Do not change any scoring logic, alias generation, or scope filtering.

---

## 2 — AI STUDY PLAN: Add persistence so the plan survives navigation

File: app/study/ai-plan/page.tsx

This is a client component. It currently generates a plan and holds it in useState — navigating away destroys it.

Changes:
- After a plan is successfully generated, save it to localStorage with key `jabu_study_plan:${userId}` where userId comes from supabase.auth.getUser(). Value: JSON.stringify({ plan, generatedAt: new Date().toISOString(), courses: selectedCourses }).
- On mount, after auth resolves, check localStorage for a saved plan. If found and generatedAt is less than 7 days old, load it into state and show it immediately (skip the generation form). Show a banner above the plan: "Generated [X days ago] · [Regenerate] [Clear]"
- "Regenerate" button: clears localStorage and resets to the form state so the user can generate a fresh plan.
- "Clear" button: clears localStorage and resets to the form state.
- Add a "Mark complete" checkbox to each StudyDay card. Store completion state in localStorage under `jabu_study_plan_progress:${userId}`. When a day is marked complete, show a green checkmark and strike-through the day's focus text.
- Add an "Export as text" button at the bottom of a generated plan. It should compile the plan into a plain-text string (week by week, day by day) and trigger a browser download as study-plan.txt using a Blob + URL.createObjectURL approach.
- No DB changes needed — localStorage only.

---

## 3 — ONBOARDING: Add a results screen as the final step

File: app/study/onboarding/OnboardingClient.tsx

The onboarding currently has 3 steps (faculty → dept → level/semester) and redirects to /study on completion. 

Changes:
- After the preferences are saved to Supabase (the existing upsert), do NOT immediately redirect to /study. Instead, transition to a new step 4: a results screen.
- On entering step 4, fetch in parallel:
  a. Count of approved materials for the user's department_id and level: supabase.from('study_materials').select('id', { count: 'exact', head: true }).eq('approved', true) with a join or filter on study_courses matching the department and level.
  b. Count of published quiz sets for the user's level: supabase.from('study_quiz_sets').select('id', { count: 'exact', head: true }).eq('published', true).eq('level', selectedLevel)
  c. Count of unanswered questions for the user's level: supabase.from('study_questions').select('id', { count: 'exact', head: true }).eq('solved', false).eq('level', String(selectedLevel))
- Show a loading skeleton while fetching (3 pill-shaped skeleton divs).
- Once loaded, render the results screen inside a Card with:
  - A large heading: "You're in." (font-extrabold text-2xl)
  - A subheading: "{deptName} · {level}L · {semester} Semester"
  - Three stat chips in a flex-wrap row: "{N} materials available" · "{N} practice sets" · "{N} open questions"
  - If any count is 0, still show it — "0 practice sets" is honest and sets expectations.
  - Three CTA cards in a grid (sm:grid-cols-3 gap-3 mt-6):
    Card 1: "Browse materials" → /study/materials (icon: BookOpen)
    Card 2: "Start practising" → /study/practice (icon: Zap — import from lucide-react)
    Card 3: "Ask a question" → /study/questions/ask (icon: MessageCircleQuestion — import from lucide-react)
  - Each card: rounded-2xl border bg-background p-4 flex flex-col gap-2 hover:bg-secondary/30 transition as a Link
  - Below the cards: a plain text link "Go to Study Hub →" that navigates to /study
- There is no "Back" button on step 4 — the form is done.
- Handle fetch errors gracefully: if counts fail, show the results screen with "—" for the counts rather than crashing.

---

## 4 — MOBILE TABS: Promote Q&A to visible tab on mobile

File: app/study/_components/StudyTabs.tsx

The MOBILE_TABS array currently has 3 items: Home, Materials, Practice.

Changes:
- Add Q&A as the 4th item in MOBILE_TABS:
  { href: "/study/questions", label: "Q&A", icon: <MessageCircleQuestion className="h-3.5 w-3.5" />, match: "prefix" }
  Import MessageCircleQuestion from lucide-react if not already imported.
- The mobile tab bar currently uses grid-cols based on items.length. Verify the grid renders correctly with 4 items + the More button. The existing layout uses flex with the More button on the right — adding a 4th tab may make labels too tight. If labels truncate badly, show icons only on mobile (remove the <span className="truncate">{tab.label}</span> from the mobile tab and rely on aria-label for accessibility, or show icon + abbreviated label: "Q&A" is already short enough).
- Remove Q&A from the overflowItems array in the MoreSheet since it's now a primary tab. Keep everything else in overflow unchanged.
- Do not change DESKTOP_TABS — Q&A is already visible there in the existing 5-tab desktop layout.

---

## 5 — SEMESTER BANNER: Remove the 8-second auto-dismiss

File: app/study/StudyHomeClient.tsx

Find the useEffect that sets a setTimeout to auto-dismiss the semesterPrompt after 8000ms.

Changes:
- Delete that useEffect entirely. The banner should only dismiss when the user explicitly clicks "Switch" or the "×" dismiss button — never automatically.
- No other changes to the semester prompt logic.

---

## 6 — LEADERBOARD NAMING: "Library" → "Bookmarks" in StudyTabs

File: app/study/_components/StudyTabs.tsx

In the overflowItems array, find the entry with href="/study/library".

Changes:
- Change label from "Library" to "Bookmarks"
- Change description from "Your saved materials and bookmarks" to "Your saved materials, sets and questions"
- Do not change the href, icon, or color.

Also update the page title in:
File: app/study/library/LibraryClient.tsx
Find the PageHeader component (or equivalent heading). Change the title prop/text from "Library" (or whatever it currently says) to "Bookmarks".

---

## 7 — PRACTICE RESULTS: Link to GPA calculator after session

File: app/study/practice/[setId]/PracticeTakeClient.tsx

After a practice session is submitted, a results/milestone screen is shown. Find where the score and milestone are displayed after submission (the submitted === true render branch).

Changes:
- Below the existing score display and action buttons, add a small contextual prompt:
  A div with text-sm text-muted-foreground text-center mt-4 containing:
  "Want to track how this affects your GPA? " followed by a Link to /study/gpa with class "underline underline-offset-2 font-semibold text-foreground hover:opacity-80" and text "Open GPA calculator →"
- Only show this when submitted === true and score > 0.
- Do not change any scoring logic, attempt persistence, or the milestone toast.

---

## 8 — CONTRIBUTOR STATUS HUB: Add impact stats for approved reps

File: app/study/_components/StudyUI.tsx (ContributorStatusHub component)

The ContributorStatusHub component is rendered on the Study home for users with a rep/librarian role. Find it in StudyUI.tsx.

Changes:
- When status === "approved", after the existing approved state UI, fetch and display a minimal impact row:
  - In a useEffect inside (or a new wrapper component next to) ContributorStatusHub, fetch:
    supabase.from('study_materials').select('id, downloads').eq('uploaded_by', userId) — but we don't have userId here. Instead, get it from supabase.auth.getUser() inside a useEffect.
  - Calculate: totalUploads = data.length, totalDownloads = sum of all downloads values
  - Display below the existing approved badge as a flex row of two small stat chips:
    "{totalUploads} uploads · {totalDownloads} downloads"
    Style: text-xs text-muted-foreground with a small inline count badge (rounded-full bg-secondary px-2 py-0.5 font-semibold text-foreground)
  - If the fetch fails or returns empty, show nothing (don't render the stats row).
  - This fetch should only run when status === "approved". For pending/rejected/not_applied, no fetch.
- Note: study_materials may use uploader_id or user_id as the column name for who uploaded it — check the existing upload page (app/study/materials/upload/page.tsx) to find the correct column name used in the insert, then use the same column in the select filter here.

---

RULES:
1. Read CLAUDE.md before starting.
2. Use the browser supabase client (lib/supabase.ts) in all client components. Never import server client in "use client" files.
3. Run through each change one at a time. Do not batch unrelated files into one edit.
4. Do not add "use client" to any file that is currently a Server Component.
5. Do not modify any /api route files.
6. All new UI must use existing Tailwind classes consistent with the surrounding code — no inline styles, no new CSS files.
7. If a lucide-react icon is needed and not already imported in a file, add it to the existing import statement.
8. After all changes, run: npm run lint and fix any errors before finishing.