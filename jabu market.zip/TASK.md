Read CLAUDE.md first.

GOAL: Make every page in the app feel instantly responsive by adding 
loading.tsx skeleton screens to all routes, and fixing the 3 client 
component pages that fetch data on mount when they should use the 
server.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
HOW loading.tsx WORKS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Next.js App Router automatically shows loading.tsx the instant a user 
taps a link — before any data fetches. It wraps the page.tsx in a 
Suspense boundary. The user sees a skeleton immediately instead of a 
frozen screen. Once the real page is ready, it swaps in.

Each loading.tsx is a simple skeleton that mirrors the layout of 
its page.tsx. No logic, no data fetching — just animated placeholder 
shapes using:
  <div className="animate-pulse rounded-{x} bg-muted h-{n} w-{n}" />

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
SKELETON DESIGN RULES (apply to all files):
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
- Match the rough layout of the real page (1 header block, then 
  content cards/rows matching what the page actually shows)
- Use animate-pulse on a wrapper div, not on every child
- bg-muted for placeholder shapes
- rounded-3xl for card-shaped blocks, rounded-full for chips/avatars,
  rounded-2xl for list rows
- Keep each loading.tsx under 60 lines — simple is better
- Always wrap in: <div className="space-y-4 pb-28 md:pb-6">
- No imports except cn from @/lib/utils if needed — no Supabase, 
  no auth, no client hooks

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
TASK 1 — MARKETPLACE ROUTES
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Create these loading.tsx files. For each, read the corresponding 
page.tsx first to understand the layout, then build the skeleton.

app/page.tsx (home) → app/loading.tsx
  Layout: search bar + 2 featured listing cards + grid of 6 cards

app/explore/page.tsx → already has loading.tsx, SKIP

app/food/page.tsx → app/food/loading.tsx
  Layout: search bar + grid of food vendor cards (4-6 cards)

app/listing/[id]/page.tsx → app/listing/[id]/loading.tsx
  Layout: image block (h-64) + title + price + 3 action buttons + 
  description block + seller card

app/vendors/page.tsx → app/vendors/loading.tsx
  Layout: header + grid of 6 vendor cards

app/vendors/[id]/page.tsx → app/vendors/[id]/loading.tsx
  Layout: vendor header card + menu section with 4-6 item rows

app/inbox/page.tsx → app/inbox/loading.tsx
  Layout: tab row + 5 conversation rows (avatar + name + preview)

app/inbox/[conversationId]/page.tsx → app/inbox/[conversationId]/loading.tsx
  Layout: header with back + avatar + 4 chat bubble blocks alternating
  left/right

app/notifications/page.tsx → app/notifications/loading.tsx
  Layout: header + 6 notification rows (icon + text + timestamp)

app/my-orders/page.tsx → app/my-orders/loading.tsx
  Layout: header + 4 order cards (status chip + items + total)

app/my-listings/page.tsx → app/my-listings/loading.tsx
  Layout: header + grid of 4 listing cards

app/me/page.tsx → app/me/loading.tsx
  Layout: avatar hero block (h-32) + tab row + 3 field rows

app/post/page.tsx → app/post/loading.tsx
  Layout: header + form skeleton (4 input blocks + image upload area)

app/couriers/page.tsx → app/couriers/loading.tsx
  Layout: header + 4 courier cards

app/delivery/page.tsx → app/delivery/loading.tsx
  Layout: header + form block

app/delivery/requests/page.tsx → app/delivery/requests/loading.tsx
  Layout: header + 4 request rows

app/saved/page.tsx → app/saved/loading.tsx
  Layout: header + grid of 4 listing cards

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
TASK 2 — VENDOR ROUTES
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

app/vendor/page.tsx → app/vendor/loading.tsx
  Layout: vendor header card + stats row + order queue (3 rows)

app/vendor/orders/page.tsx → app/vendor/orders/loading.tsx
  Layout: header + filter chips + 4 order cards

app/vendor/menu/page.tsx → app/vendor/menu/loading.tsx
  Layout: header + 6 menu item rows (name + price + toggle)

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
TASK 3 — STUDY HUB ROUTES
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

app/study/page.tsx → app/study/loading.tsx
  Layout: tab row + search bar + streak card (h-24) + 
  welcome card (h-32) + 2 material cards

app/study/materials/page.tsx → app/study/materials/loading.tsx
  Layout: tab row + header + search bar + filter chips + 
  4 material cards

app/study/materials/[id]/page.tsx → app/study/materials/[id]/loading.tsx
  Layout: back button + title card (h-28) + action buttons row + 
  preview block (h-48) + metadata card

app/study/practice/page.tsx → app/study/practice/loading.tsx
  Layout: tab row + header + tab pills (For you/Recent/All) + 
  search bar + 4 practice set cards

app/study/practice/[setId]/page.tsx → already has loading.tsx, SKIP

app/study/questions/page.tsx → app/study/questions/loading.tsx
  Layout: tab row + header + search bar + 5 question rows

app/study/questions/[id]/page.tsx → app/study/questions/[id]/loading.tsx
  Layout: back button + question card (h-40) + answers header + 
  2 answer cards

app/study/questions/ask/page.tsx → app/study/questions/ask/loading.tsx
  Layout: header + 3 form field blocks

app/study/leaderboard/page.tsx → app/study/leaderboard/loading.tsx
  Layout: header + scope tabs + 5 leaderboard rows (rank + avatar + 
  name + points)

app/study/gpa/page.tsx → app/study/gpa/loading.tsx
  Layout: header + scale selector + semester card with 3 course rows

app/study/history/page.tsx → app/study/history/loading.tsx
  Layout: header + 4 attempt rows (course + score + date)

app/study/history/[attemptId]/page.tsx → 
  app/study/history/[attemptId]/loading.tsx
  Layout: header + score card (h-32) + 4 question review rows

app/study/tutors/page.tsx → app/study/tutors/loading.tsx
  Layout: header + search bar + 4 tutor cards

app/study/onboarding/page.tsx → app/study/onboarding/loading.tsx
  Layout: centered stepper (4 dots) + large card (h-64)

app/study/library/page.tsx → app/study/library/loading.tsx
  Layout: header + tab row + 4 saved item rows

app/study/search/page.tsx → app/study/search/loading.tsx
  Layout: search bar + filter chips + 4 result rows

app/study/ai-plan/page.tsx → app/study/ai-plan/loading.tsx
  Layout: header + generate button + plan card (h-48)

app/study/courses/[code]/page.tsx → app/study/courses/[code]/loading.tsx
  Layout: header + course info card + 4 material rows

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
TASK 4 — STUDY ADMIN ROUTES
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

app/study-admin/page.tsx → app/study-admin/loading.tsx
  Layout: nav shell + 4 stat cards

app/study-admin/materials/page.tsx → app/study-admin/materials/loading.tsx
  Layout: nav shell + filter row + 5 material rows with action buttons

app/study-admin/history/page.tsx → app/study-admin/history/loading.tsx
  Layout: nav shell + filter row + table with 6 rows

app/study-admin/upload/page.tsx → app/study-admin/upload/loading.tsx
  Layout: nav shell + form with 6 input blocks + dropzone area

app/study-admin/courses/page.tsx → app/study-admin/courses/loading.tsx
  Layout: nav shell + filter row + 5 course rows

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
TASK 5 — FIX CLIENT PAGES FETCHING ON MOUNT
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
These 3 pages are "use client" and fetch data in useEffect. They should
be split into a server page.tsx that fetches + a client component for
interactivity. Read each file fully before touching.

FILE: app/my-orders/page.tsx
Currently: "use client", fetches orders in useEffect
Fix:
  1. Convert page.tsx to a Server Component (remove "use client")
  2. Fetch orders server-side using createSupabaseServerClient()
     Query: orders where buyer_id = user.id, order by created_at desc
     Include: vendor name (join vendors on vendor_id)
  3. Pass orders as prop to a new MyOrdersClient.tsx component that
     handles the interactive parts (status filtering, cancel button)
  4. page.tsx handles auth redirect if no session

FILE: app/notifications/page.tsx  
Currently: "use client", fetches notifications in useEffect
Fix:
  1. Convert page.tsx to Server Component
  2. Fetch notifications server-side: 
     SELECT * FROM notifications WHERE user_id = me 
     ORDER BY created_at DESC LIMIT 50
  3. Also mark all as read server-side after fetching (UPDATE)
  4. Pass to NotificationsClient.tsx for rendering

FILE: app/me/page.tsx
Currently: "use client" (partially)
Read the file first — it may already be partially server-side.
If the main data fetch (profile, vendor, listings) is in useEffect,
move it to a server-side fetch in page.tsx and pass as initialData prop.
Do NOT rewrite the whole component — only move the initial data fetch.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
RULES:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
- Do TASK 1 → 2 → 3 → 4 → 5 in order
- For loading.tsx files: create them, don't over-engineer them
- For Task 5: read the full file before touching it — surgical edits
- No new dependencies, no any types
- After all tasks: list every file created/modified
- If a page.tsx for a route doesn't exist (like /saved), note it and 
  skip — don't create pages that don't exist