// app/notifications/page.tsx
import NotificationsClient from "./NotificationsClient";

export default function NotificationsPage() {
  return <NotificationsClient />;
}
