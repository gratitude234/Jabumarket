import { Suspense } from "react";
import OnboardingClient from "./OnboardingClient";

export default function StudyOnboardingPage() {
  return (
    <div className="mx-auto w-full max-w-2xl px-4 py-6">
      <Suspense
        fallback={<div className="rounded-3xl border bg-white p-4">Loading…</div>}
      >
        <OnboardingClient />
      </Suspense>
    </div>
  );
}
