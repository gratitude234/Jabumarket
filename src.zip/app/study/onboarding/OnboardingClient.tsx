"use client";

import { useEffect, useMemo, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { supabase } from "@/lib/supabase";
import { ArrowRight, Building2, Layers, Loader2, School } from "lucide-react";

function cn(...c: Array<string | false | null | undefined>) {
  return c.filter(Boolean).join(" ");
}

const SEMESTERS = [
  { value: "first", label: "1st Semester" },
  { value: "second", label: "2nd Semester" },
  { value: "summer", label: "Summer" },
];

type FacultyRow = { id: string; name: string; sort_order?: number | null };
type DeptRow = { id: string; faculty_id: string; display_name?: string; official_name?: string; sort_order?: number | null };

export default function OnboardingClient() {
  const router = useRouter();
  const sp = useSearchParams();

  const next = useMemo(() => {
    const raw = (sp.get("next") ?? "/study").trim();
    return raw.startsWith("/") ? raw : "/study";
  }, [sp]);

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  // Dropdown data (official list)
  const [dropdownMode, setDropdownMode] = useState(true);
  const [faculties, setFaculties] = useState<FacultyRow[]>([]);
  const [departments, setDepartments] = useState<DeptRow[]>([]);
  const [facultyId, setFacultyId] = useState<string>("");
  const [departmentId, setDepartmentId] = useState<string>("");

  const [faculty, setFaculty] = useState("");
  const [department, setDepartment] = useState("");
  const [level, setLevel] = useState<number | "">("");
  const [semester, setSemester] = useState<string>("");

  useEffect(() => {
    let mounted = true;

    (async () => {
      setLoading(true);

      const { data: auth } = await supabase.auth.getUser();
      const user = auth?.user;
      if (!user) {
        router.replace(`/login?next=${encodeURIComponent("/study/onboarding")}`);
        return;
      }

      // Try to load the official faculties list (views). If missing, fall back to manual inputs.
      const facRes = await supabase
        .from("study_faculties_clean")
        .select("id,name,sort_order")
        .order("sort_order", { ascending: true })
        .order("name", { ascending: true });

      if (mounted) {
        if (facRes.error) {
          setDropdownMode(false);
          setFaculties([]);
        } else {
          setDropdownMode(true);
          setFaculties((facRes.data ?? []) as FacultyRow[]);
        }
      }

      const { data, error } = await supabase
        .from("study_user_preferences")
        .select("faculty_id,department_id,faculty,department,level,semester")
        .eq("user_id", user.id)
        .maybeSingle();

      // If table doesn't exist yet, allow the page to render so user can proceed.
      if (!mounted) return;

      const d: any = data;
      const alreadyDone = !!(
        d?.level &&
        d?.semester &&
        ((d?.faculty_id && d?.department_id) || (d?.faculty && d?.department))
      );

      if (!error && alreadyDone) {
        router.replace(next);
        return;
      }

      if (!error && data) {
        if (typeof d.faculty_id === "string") setFacultyId(d.faculty_id);
        if (typeof d.department_id === "string") setDepartmentId(d.department_id);
        if (typeof d.faculty === "string") setFaculty(d.faculty);
        if (typeof d.department === "string") setDepartment(d.department);
        if (typeof d.level === "number") setLevel(d.level);
        if (typeof d.semester === "string") setSemester(d.semester);
      }

      setLoading(false);
    })();

    return () => {
      mounted = false;
    };
  }, [router, next]);

  // Load departments when a faculty is chosen (dropdown mode)
  useEffect(() => {
    if (!dropdownMode) return;
    if (!facultyId) {
      setDepartments([]);
      setDepartmentId("");
      return;
    }

    let mounted = true;
    (async () => {
      const res = await supabase
        .from("study_departments_clean")
        .select("id,faculty_id,display_name,official_name,sort_order")
        .eq("faculty_id", facultyId)
        .order("sort_order", { ascending: true })
        .order("display_name", { ascending: true });

      if (!mounted) return;
      if (res.error) {
        setDropdownMode(false);
        setDepartments([]);
        return;
      }
      setDepartments((res.data ?? []) as DeptRow[]);
    })();

    return () => {
      mounted = false;
    };
  }, [dropdownMode, facultyId]);

  const valid =
    (dropdownMode ? !!facultyId && !!departmentId : faculty.trim().length >= 2 && department.trim().length >= 2) &&
    typeof level === "number" &&
    Number.isFinite(level) &&
    semester.trim().length > 0;

  async function save() {
    if (!valid) return;
    setSaving(true);
    try {
      const { data: auth } = await supabase.auth.getUser();
      const user = auth?.user;
      if (!user) {
        router.replace(`/login?next=${encodeURIComponent("/study/onboarding")}`);
        return;
      }

      const selectedFaculty = dropdownMode
        ? faculties.find((f) => f.id === facultyId)?.name ?? ""
        : faculty.trim();
      const selectedDeptRow = dropdownMode ? departments.find((d) => d.id === departmentId) : null;
      const selectedDepartment = dropdownMode
        ? (selectedDeptRow?.display_name || selectedDeptRow?.official_name || "").trim()
        : department.trim();

      const payload: any = {
        user_id: user.id,
        faculty: selectedFaculty,
        department: selectedDepartment,
        level,
        semester,
        updated_at: new Date().toISOString(),
      };

      if (dropdownMode) {
        payload.faculty_id = facultyId;
        payload.department_id = departmentId;
      }

      const { error } = await supabase.from("study_user_preferences").upsert(payload);
      if (error) throw error;

      router.replace(next);
      router.refresh();
    } catch (e: any) {
      alert(e?.message ?? "Failed to save. Try again.");
    } finally {
      setSaving(false);
    }
  }

  if (loading) {
    return <div className="rounded-3xl border bg-white p-4">Loading…</div>;
  }

  return (
    <div className="space-y-4">
      <div className="rounded-3xl border bg-white p-4">
        <p className="text-lg font-bold text-zinc-900">Set up Jabu Study</p>
        <p className="mt-1 text-sm text-zinc-600">
          This helps us show the right materials and practice sets for you.
        </p>
      </div>

      <div className="rounded-3xl border bg-white p-4 space-y-3">
        {dropdownMode ? (
          <>
            <label className="block rounded-2xl border bg-white px-3 py-2">
              <span className="text-xs font-semibold text-zinc-600 inline-flex items-center gap-2">
                <School className="h-4 w-4" /> Faculty
              </span>
              <select
                value={facultyId}
                onChange={(e) => {
                  setFacultyId(e.target.value);
                  setDepartmentId("");
                }}
                className="mt-1 w-full bg-transparent text-sm text-zinc-900 outline-none"
              >
                <option value="">Select faculty</option>
                {faculties.map((f) => (
                  <option key={f.id} value={f.id}>
                    {f.name}
                  </option>
                ))}
              </select>
            </label>

            <label className="block rounded-2xl border bg-white px-3 py-2">
              <span className="text-xs font-semibold text-zinc-600 inline-flex items-center gap-2">
                <Building2 className="h-4 w-4" /> Department
              </span>
              <select
                value={departmentId}
                onChange={(e) => setDepartmentId(e.target.value)}
                disabled={!facultyId}
                className="mt-1 w-full bg-transparent text-sm text-zinc-900 outline-none disabled:opacity-70"
              >
                <option value="">{facultyId ? "Select department" : "Select faculty first"}</option>
                {departments.map((d) => (
                  <option key={d.id} value={d.id}>
                    {d.display_name || d.official_name || "Department"}
                  </option>
                ))}
              </select>
            </label>

            <button
              type="button"
              onClick={() => setDropdownMode(false)}
              className="text-left text-xs font-semibold text-zinc-600 hover:text-zinc-900"
            >
              Can’t find your department? Tap to type manually.
            </button>
          </>
        ) : (
          <>
            <label className="block rounded-2xl border bg-white px-3 py-2">
              <span className="text-xs font-semibold text-zinc-600 inline-flex items-center gap-2">
                <School className="h-4 w-4" /> Faculty
              </span>
              <input
                value={faculty}
                onChange={(e) => setFaculty(e.target.value)}
                placeholder="e.g. College of Health Sciences"
                className="mt-1 w-full bg-transparent text-sm text-zinc-900 outline-none"
              />
            </label>

            <label className="block rounded-2xl border bg-white px-3 py-2">
              <span className="text-xs font-semibold text-zinc-600 inline-flex items-center gap-2">
                <Building2 className="h-4 w-4" /> Department
              </span>
              <input
                value={department}
                onChange={(e) => setDepartment(e.target.value)}
                placeholder="e.g. Nursing"
                className="mt-1 w-full bg-transparent text-sm text-zinc-900 outline-none"
              />
            </label>

            <button
              type="button"
              onClick={() => setDropdownMode(true)}
              className="text-left text-xs font-semibold text-zinc-600 hover:text-zinc-900"
            >
              Prefer dropdowns? Tap to use the official list.
            </button>
          </>
        )}

        <div className="grid gap-2 sm:grid-cols-2">
          <label className="block rounded-2xl border bg-white px-3 py-2">
            <span className="text-xs font-semibold text-zinc-600 inline-flex items-center gap-2">
              <Layers className="h-4 w-4" /> Level
            </span>
            <select
              value={level === "" ? "" : String(level)}
              onChange={(e) => setLevel(e.target.value ? Number(e.target.value) : "")}
              className="mt-1 w-full bg-transparent text-sm text-zinc-900 outline-none"
            >
              <option value="">Select level</option>
              <option value="100">100</option>
              <option value="200">200</option>
              <option value="300">300</option>
              <option value="400">400</option>
              <option value="500">500</option>
            </select>
          </label>

          <label className="block rounded-2xl border bg-white px-3 py-2">
            <span className="text-xs font-semibold text-zinc-600">Semester</span>
            <select
              value={semester}
              onChange={(e) => setSemester(e.target.value)}
              className="mt-1 w-full bg-transparent text-sm text-zinc-900 outline-none"
            >
              <option value="">Select semester</option>
              {SEMESTERS.map((s) => (
                <option key={s.value} value={s.value}>
                  {s.label}
                </option>
              ))}
            </select>
          </label>
        </div>

        <button
          onClick={save}
          disabled={!valid || saving}
          className={cn(
            "w-full inline-flex items-center justify-center gap-2 rounded-2xl border px-4 py-3 text-sm font-semibold",
            valid ? "bg-zinc-900 text-white hover:bg-zinc-800" : "bg-zinc-100 text-zinc-500",
            "disabled:opacity-70"
          )}
        >
          {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <ArrowRight className="h-4 w-4" />}
          Continue to Study
        </button>
      </div>
    </div>
  );
}
