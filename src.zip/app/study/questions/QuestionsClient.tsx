// app/study/questions/QuestionsClient.tsx
"use client";

import Link from "next/link";
import { useEffect, useMemo, useRef, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { supabase } from "@/lib/supabase";
import {
  ArrowLeft,
  MessageSquare,
  Search,
  Plus,
  Filter,
  X,
  ChevronRight,
  ThumbsUp,
  Bookmark,
  BookmarkCheck,
} from "lucide-react";

import { getAuthedUserId, toggleSaved } from "@/lib/studySaved";

import StudyTabs from "../_components/StudyTabs";
function cn(...parts: Array<string | false | null | undefined>) {
  return parts.filter(Boolean).join(" ");
}

function normalizeQuery(v: string) {
  return v.trim().replace(/\s+/g, " ");
}

function formatWhen(iso?: string | null) {
  if (!iso) return "";
  const t = new Date(iso).getTime();
  if (!Number.isFinite(t)) return "";
  const diff = Date.now() - t;
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return "just now";
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  const days = Math.floor(hrs / 24);
  return `${days}d ago`;
}

type QuestionRow = {
  id: string;
  title: string;
  body: string | null;
  course_code: string | null;
  level: string | null;
  created_at: string | null;
  answers_count: number | null;
  upvotes_count: number | null;
  solved: boolean | null;
};

const LEVELS = ["100", "200", "300", "400", "500"] as const;

function buildHref(path: string, params: Record<string, string | null | undefined>) {
  const sp = new URLSearchParams();
  Object.entries(params).forEach(([k, v]) => {
    const s = (v ?? "").trim();
    if (!s) return;
    sp.set(k, s);
  });
  const qs = sp.toString();
  return qs ? `${path}?${qs}` : path;
}

function Chip({
  active,
  children,
  onClick,
}: {
  active?: boolean;
  children: React.ReactNode;
  onClick?: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        "inline-flex items-center gap-2 rounded-full border px-3 py-2 text-sm font-semibold transition",
        active
          ? "border-zinc-900 bg-zinc-900 text-white"
          : "border-zinc-200 bg-white text-zinc-900 hover:bg-zinc-50"
      )}
    >
      {children}
    </button>
  );
}

export default function QuestionsClient() {
  const router = useRouter();
  const sp = useSearchParams();

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [questions, setQuestions] = useState<QuestionRow[]>([]);

  const [savedIds, setSavedIds] = useState<Set<string>>(new Set());
  const [savingId, setSavingId] = useState<string | null>(null);

  const [q, setQ] = useState(sp.get("q") ?? "");
  const [course, setCourse] = useState(sp.get("course") ?? "");
  const [level, setLevel] = useState(sp.get("level") ?? "");
  const [onlyUnsolved, setOnlyUnsolved] = useState((sp.get("unsolved") ?? "") === "1");

  const debounceRef = useRef<number | null>(null);

  const filters = useMemo(
    () => ({
      q: normalizeQuery(q),
      course: course.trim().toUpperCase(),
      level: level.trim(),
      unsolved: onlyUnsolved ? "1" : "",
    }),
    [q, course, level, onlyUnsolved]
  );

  useEffect(() => {
    if (debounceRef.current) window.clearTimeout(debounceRef.current);
    debounceRef.current = window.setTimeout(() => {
      router.replace(buildHref("/study/questions", filters));
    }, 250);
    return () => {
      if (debounceRef.current) window.clearTimeout(debounceRef.current);
    };
  }, [filters, router]);

  async function load() {
    setLoading(true);
    setError(null);
    try {
      let query = supabase
        .from("study_questions")
        .select(
          "id,title,body,course_code,level,created_at,answers_count,upvotes_count,solved"
        )
        .order("created_at", { ascending: false })
        .limit(60);

      if (filters.course) query = query.ilike("course_code", filters.course);
      if (filters.level) query = query.eq("level", filters.level);
      if (filters.unsolved) query = query.eq("solved", false);
      if (filters.q) {
        query = query.or(`title.ilike.%${filters.q}%,body.ilike.%${filters.q}%`);
      }

      const { data, error } = await query;
      if (error) throw error;
      setQuestions((data as any) ?? []);
    } catch (e: any) {
      setError(e?.message ?? "Failed to load questions.");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [filters.q, filters.course, filters.level, filters.unsolved]);

  // Load saved question ids for visible list
  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const userId = await getAuthedUserId();
        if (!userId) {
          if (!cancelled) setSavedIds(new Set());
          return;
        }
        const ids = questions.map((q) => q.id).filter(Boolean);
        if (ids.length === 0) {
          if (!cancelled) setSavedIds(new Set());
          return;
        }
        const { data, error } = await supabase
          .from("study_saved_items")
          .select("question_id")
          .eq("user_id", userId)
          .eq("item_type", "question")
          .in("question_id", ids);
        if (error) throw error;
        const next = new Set<string>();
        (data ?? []).forEach((r: any) => {
          if (r?.question_id) next.add(String(r.question_id));
        });
        if (!cancelled) setSavedIds(next);
      } catch {
        if (!cancelled) setSavedIds(new Set());
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [questions]);

  async function onToggleQuestionSave(questionId: string) {
    setSavingId(questionId);
    setSavedIds((prev) => {
      const n = new Set(prev);
      if (n.has(questionId)) n.delete(questionId);
      else n.add(questionId);
      return n;
    });
    try {
      await toggleSaved({ itemType: "question", questionId });
    } catch (e: any) {
      setSavedIds((prev) => {
        const n = new Set(prev);
        if (n.has(questionId)) n.delete(questionId);
        else n.add(questionId);
        return n;
      });
      alert(e?.message ?? "Could not save. Try again.");
    } finally {
      setSavingId(null);
    }
  }

  return (
    <div className="mx-auto w-full max-w-3xl px-4 pb-24 pt-6">
      
      {/* Study sub-nav (sticky on mobile) */}
      <StudyTabs />
<div className="mb-5 flex items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <Link
            href="/study"
            className="grid h-10 w-10 place-items-center rounded-2xl border bg-white hover:bg-zinc-50"
            aria-label="Back"
          >
            <ArrowLeft className="h-4 w-4" />
          </Link>
          <div>
            <p className="text-lg font-semibold text-zinc-900">Study Q&amp;A</p>
            <p className="text-sm text-zinc-600">Ask questions, get answers from students.</p>
          </div>
        </div>
        <Link
          href="/study/questions/ask"
          className="inline-flex items-center gap-2 rounded-2xl bg-zinc-900 px-4 py-2 text-sm font-semibold text-white hover:bg-zinc-800"
        >
          <Plus className="h-4 w-4" />
          Ask
        </Link>
      </div>

      <div className="mb-3 rounded-3xl border bg-white p-3">
        <div className="flex items-center gap-2">
          <div className="grid h-10 w-10 place-items-center rounded-2xl bg-zinc-50">
            <Search className="h-4 w-4 text-zinc-700" />
          </div>
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Search questions (title or details)…"
            className="h-10 w-full bg-transparent text-sm text-zinc-900 outline-none"
          />
          {(q || course || level || onlyUnsolved) && (
            <button
              type="button"
              onClick={() => {
                setQ("");
                setCourse("");
                setLevel("");
                setOnlyUnsolved(false);
              }}
              className="grid h-10 w-10 place-items-center rounded-2xl border bg-white hover:bg-zinc-50"
              aria-label="Clear"
            >
              <X className="h-4 w-4" />
            </button>
          )}
        </div>
        <div className="mt-3 flex flex-wrap gap-2">
          <Chip active={onlyUnsolved} onClick={() => setOnlyUnsolved((v) => !v)}>
            <Filter className="h-4 w-4" /> Unsolved
          </Chip>
          <div className="flex flex-1 flex-wrap gap-2">
            <input
              value={course}
              onChange={(e) => setCourse(e.target.value)}
              placeholder="Course code (e.g., GST101)"
              className="h-10 min-w-[180px] flex-1 rounded-2xl border bg-white px-3 text-sm outline-none"
            />
            <select
              value={level}
              onChange={(e) => setLevel(e.target.value)}
              className="h-10 rounded-2xl border bg-white px-3 text-sm outline-none"
            >
              <option value="">All levels</option>
              {LEVELS.map((lv) => (
                <option key={lv} value={lv}>
                  {lv}L
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      <div className="space-y-3">
        {loading && (
          <div className="rounded-3xl border bg-white p-4 text-sm text-zinc-600">Loading questions…</div>
        )}
        {!loading && error && (
          <div className="rounded-3xl border border-red-200 bg-red-50 p-4 text-sm text-red-700">
            {error}
            <button
              type="button"
              onClick={load}
              className="ml-3 inline-flex items-center gap-2 rounded-2xl border border-red-200 bg-white px-3 py-2 text-xs font-semibold text-red-700 hover:bg-red-50"
            >
              Retry
            </button>
          </div>
        )}
        {!loading && !error && questions.length === 0 && (
          <div className="rounded-3xl border bg-white p-6">
            <p className="text-base font-semibold text-zinc-900">No questions yet</p>
            <p className="mt-1 text-sm text-zinc-600">Be the first to ask a question for your course.</p>
            <Link
              href="/study/questions/ask"
              className="mt-4 inline-flex items-center gap-2 rounded-2xl bg-zinc-900 px-4 py-2 text-sm font-semibold text-white hover:bg-zinc-800"
            >
              <Plus className="h-4 w-4" /> Ask a question
            </Link>
          </div>
        )}

        {questions.map((it) => {
          const saved = savedIds.has(it.id);
          const saving = savingId === it.id;
          return (
          <Link
            key={it.id}
            href={`/study/questions/${it.id}`}
            className="block rounded-3xl border bg-white p-4 transition hover:bg-zinc-50"
          >
            <div className="flex items-start justify-between gap-3">
              <div className="min-w-0 flex-1">
                <div className="flex flex-wrap items-center gap-2">
                  {it.solved ? (
                    <span className="rounded-full bg-emerald-50 px-2.5 py-1 text-xs font-semibold text-emerald-700">Solved</span>
                  ) : (
                    <span className="rounded-full bg-zinc-100 px-2.5 py-1 text-xs font-semibold text-zinc-700">Open</span>
                  )}
                  {it.course_code && (
                    <span className="rounded-full border bg-white px-2.5 py-1 text-xs font-semibold text-zinc-800">{it.course_code}</span>
                  )}
                  {it.level && (
                    <span className="rounded-full border bg-white px-2.5 py-1 text-xs font-semibold text-zinc-800">{it.level}L</span>
                  )}
                </div>
                <p className="mt-2 line-clamp-2 text-base font-semibold text-zinc-900">{it.title}</p>
                {it.body ? <p className="mt-1 line-clamp-2 text-sm text-zinc-600">{it.body}</p> : null}
                <div className="mt-3 flex flex-wrap items-center gap-3 text-xs text-zinc-600">
                  <span className="inline-flex items-center gap-1">
                    <MessageSquare className="h-3.5 w-3.5" /> {it.answers_count ?? 0}
                  </span>
                  <span className="inline-flex items-center gap-1">
                    <ThumbsUp className="h-3.5 w-3.5" /> {it.upvotes_count ?? 0}
                  </span>
                  <span>{formatWhen(it.created_at)}</span>
                </div>

                <div className="mt-3 flex items-center gap-2">
                  <button
                    type="button"
                    onClick={(e) => {
                      e.preventDefault();
                      e.stopPropagation();
                      onToggleQuestionSave(it.id);
                    }}
                    disabled={saving}
                    className={cn(
                      "inline-flex items-center gap-2 rounded-2xl border px-3 py-2 text-xs font-semibold transition",
                      saved
                        ? "border-zinc-900 bg-zinc-900 text-white hover:bg-zinc-800"
                        : "border-zinc-200 bg-white text-zinc-900 hover:bg-zinc-50",
                      saving ? "opacity-70" : ""
                    )}
                  >
                    {saved ? <BookmarkCheck className="h-4 w-4" /> : <Bookmark className="h-4 w-4" />}
                    {saved ? "Saved" : "Save"}
                  </button>
                </div>
              </div>
              <ChevronRight className="mt-2 h-4 w-4 text-zinc-400" />
            </div>
          </Link>
        )})}
      </div>
    </div>
  );
}
