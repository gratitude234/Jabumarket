// app/study/questions/ask/page.tsx
import AskQuestionClient from "./AskQuestionClient";

export const metadata = {
  title: "Ask a Question • Jabu Study",
};

export default function AskQuestionPage() {
  return <AskQuestionClient />;
}
