// app/study/questions/page.tsx
import QuestionsClient from "./QuestionsClient";

export const metadata = {
  title: "Study Q&A • Jabu Study",
};

export default function StudyQuestionsPage() {
  return <QuestionsClient />;
}
