import { Suspense } from "react";
import LibraryClient from "./LibraryClient";

export default function StudyLibraryPage() {
  return (
    <div className="mx-auto w-full max-w-3xl px-4 pb-24 pt-6">
      <Suspense fallback={<div className="rounded-3xl border bg-white p-4">Loading…</div>}>
        <LibraryClient />
      </Suspense>
    </div>
  );
}
