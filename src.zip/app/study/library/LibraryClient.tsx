"use client";

import Link from "next/link";
import { useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { supabase } from "@/lib/supabase";
import { BookmarkCheck, ArrowLeft, BookOpen, Sparkles, MessageSquare, Loader2, Trash2 } from "lucide-react";
import { toggleSaved, getAuthedUserId } from "@/lib/studySaved";

import StudyTabs from "../_components/StudyTabs";
function cn(...parts: Array<string | false | null | undefined>) {
  return parts.filter(Boolean).join(" ");
}

type SavedRow = {
  id: string;
  item_type: "material" | "practice_set" | "question";
  material_id: string | null;
  practice_set_id: string | null;
  question_id: string | null;
  created_at: string | null;
};

type Material = {
  id: string;
  title: string | null;
  description: string | null;
  file_url: string | null;
  created_at: string | null;
  downloads: number | null;
};

type QuizSet = {
  id: string;
  title: string;
  description: string | null;
  course_code: string | null;
  level: string | null;
  created_at: string | null;
  time_limit_minutes: number | null;
  questions_count: number | null;
};

type Question = {
  id: string;
  title: string;
  body: string | null;
  course_code: string | null;
  level: string | null;
  created_at: string | null;
  answers_count: number | null;
  upvotes_count: number | null;
  solved: boolean | null;
};

type TabKey = "materials" | "practice" | "questions";

function formatWhen(iso?: string | null) {
  if (!iso) return "";
  const t = new Date(iso).getTime();
  if (!Number.isFinite(t)) return "";
  const diff = Date.now() - t;
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return "just now";
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  const days = Math.floor(hrs / 24);
  return `${days}d ago`;
}

function Tab({ active, onClick, children }: { active: boolean; onClick: () => void; children: React.ReactNode }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        "inline-flex items-center gap-2 rounded-full border px-3 py-2 text-sm font-semibold transition",
        active ? "border-zinc-900 bg-zinc-900 text-white" : "border-zinc-200 bg-white text-zinc-900 hover:bg-zinc-50"
      )}
    >
      {children}
    </button>
  );
}

export default function LibraryClient() {
  const router = useRouter();
  const [tab, setTab] = useState<TabKey>("materials");
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState<string | null>(null);
  const [savingId, setSavingId] = useState<string | null>(null);

  const [saved, setSaved] = useState<SavedRow[]>([]);
  const [materialsById, setMaterialsById] = useState<Record<string, Material>>({});
  const [setsById, setSetsById] = useState<Record<string, QuizSet>>({});
  const [questionsById, setQuestionsById] = useState<Record<string, Question>>({});

  const counts = useMemo(() => {
    let m = 0,
      p = 0,
      q = 0;
    for (const r of saved) {
      if (r.item_type === "material") m++;
      if (r.item_type === "practice_set") p++;
      if (r.item_type === "question") q++;
    }
    return { m, p, q };
  }, [saved]);

  async function loadAll() {
    setLoading(true);
    setErr(null);
    try {
      const userId = await getAuthedUserId();
      if (!userId) {
        router.replace(`/login?next=${encodeURIComponent("/study/library")}`);
        return;
      }

      const { data: savedRows, error: savedErr } = await supabase
        .from("study_saved_items")
        .select("id,item_type,material_id,practice_set_id,question_id,created_at")
        .eq("user_id", userId)
        .order("created_at", { ascending: false })
        .limit(250);
      if (savedErr) throw savedErr;
      const rows = ((savedRows as any) ?? []) as SavedRow[];
      setSaved(rows);

      const materialIds = Array.from(new Set(rows.filter((r) => r.material_id).map((r) => r.material_id!)));
      const setIds = Array.from(new Set(rows.filter((r) => r.practice_set_id).map((r) => r.practice_set_id!)));
      const questionIds = Array.from(new Set(rows.filter((r) => r.question_id).map((r) => r.question_id!)));

      // Materials
      if (materialIds.length) {
        const { data, error } = await supabase
          .from("study_materials")
          .select("id,title,description,file_url,created_at,downloads")
          .in("id", materialIds);
        if (!error) {
          const map: Record<string, Material> = {};
          (data as any[] | null)?.forEach((m) => {
            map[String(m.id)] = m as Material;
          });
          setMaterialsById(map);
        }
      } else {
        setMaterialsById({});
      }

      // Practice sets (optional table)
      if (setIds.length) {
        const { data, error } = await supabase
          .from("study_quiz_sets")
          .select("id,title,description,course_code,level,created_at,time_limit_minutes,questions_count")
          .in("id", setIds);
        if (!error) {
          const map: Record<string, QuizSet> = {};
          (data as any[] | null)?.forEach((s) => {
            map[String(s.id)] = s as QuizSet;
          });
          setSetsById(map);
        }
      } else {
        setSetsById({});
      }

      // Questions (optional table)
      if (questionIds.length) {
        const { data, error } = await supabase
          .from("study_questions")
          .select("id,title,body,course_code,level,created_at,answers_count,upvotes_count,solved")
          .in("id", questionIds);
        if (!error) {
          const map: Record<string, Question> = {};
          (data as any[] | null)?.forEach((q) => {
            map[String(q.id)] = q as Question;
          });
          setQuestionsById(map);
        }
      } else {
        setQuestionsById({});
      }
    } catch (e: any) {
      setErr(e?.message ?? "Failed to load library");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    loadAll();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function removeItem(row: SavedRow) {
    setSavingId(row.id);
    // Optimistic remove
    setSaved((prev) => prev.filter((x) => x.id !== row.id));
    try {
      if (row.item_type === "material" && row.material_id) {
        await toggleSaved({ itemType: "material", materialId: row.material_id });
      }
      if (row.item_type === "practice_set" && row.practice_set_id) {
        await toggleSaved({ itemType: "practice_set", practiceSetId: row.practice_set_id });
      }
      if (row.item_type === "question" && row.question_id) {
        await toggleSaved({ itemType: "question", questionId: row.question_id });
      }
    } catch (e: any) {
      alert(e?.message ?? "Could not remove. Try again.");
      // Re-load to be safe
      await loadAll();
    } finally {
      setSavingId(null);
    }
  }

  const visible = useMemo(() => {
    if (tab === "materials") return saved.filter((r) => r.item_type === "material");
    if (tab === "practice") return saved.filter((r) => r.item_type === "practice_set");
    return saved.filter((r) => r.item_type === "question");
  }, [saved, tab]);

  return (
    <div>
      
      {/* Study sub-nav (sticky on mobile) */}
      <StudyTabs />
<div className="flex items-center gap-3">
        <button
          type="button"
          onClick={() => router.back()}
          className="inline-flex items-center gap-2 rounded-2xl border bg-white px-4 py-2 text-sm font-semibold text-zinc-900 hover:bg-zinc-50"
        >
          <ArrowLeft className="h-4 w-4" /> Back
        </button>
        <div className="min-w-0">
          <p className="text-xl font-extrabold tracking-tight text-zinc-900">My Library</p>
          <p className="mt-1 text-sm text-zinc-600">Everything you saved — materials, practice sets, and questions.</p>
        </div>
      </div>

      <div className="mt-4 rounded-3xl border bg-white p-4 shadow-sm">
        <div className="flex flex-wrap items-center gap-2">
          <Tab active={tab === "materials"} onClick={() => setTab("materials")}>
            <BookOpen className="h-4 w-4" /> Materials ({counts.m})
          </Tab>
          <Tab active={tab === "practice"} onClick={() => setTab("practice")}>
            <Sparkles className="h-4 w-4" /> Practice ({counts.p})
          </Tab>
          <Tab active={tab === "questions"} onClick={() => setTab("questions")}>
            <MessageSquare className="h-4 w-4" /> Questions ({counts.q})
          </Tab>

          <span className="ml-auto inline-flex items-center gap-2 rounded-full border bg-zinc-50 px-3 py-2 text-sm font-semibold text-zinc-700">
            <BookmarkCheck className="h-4 w-4" /> Saved
          </span>
        </div>
      </div>

      <div className="mt-4 grid gap-3">
        {loading ? (
          <div className="rounded-3xl border bg-white p-6 shadow-sm">
            <div className="flex items-center gap-2 text-sm font-semibold text-zinc-700">
              <Loader2 className="h-4 w-4 animate-spin" /> Loading…
            </div>
          </div>
        ) : err ? (
          <div className="rounded-3xl border bg-white p-6 shadow-sm">
            <p className="text-sm font-semibold text-zinc-900">Couldn’t load your library</p>
            <p className="mt-1 text-sm text-zinc-600">{err}</p>
            <button
              type="button"
              onClick={loadAll}
              className="mt-3 inline-flex items-center gap-2 rounded-2xl border bg-white px-4 py-2 text-sm font-semibold text-zinc-900 hover:bg-zinc-50"
            >
              Retry
            </button>
          </div>
        ) : visible.length === 0 ? (
          <div className="rounded-3xl border bg-white p-6 shadow-sm">
            <p className="text-sm font-semibold text-zinc-900">Nothing saved yet</p>
            <p className="mt-1 text-sm text-zinc-600">Save items you want to revisit quickly.</p>
            <div className="mt-3 flex flex-wrap gap-2">
              <Link href="/study/materials" className="inline-flex items-center gap-2 rounded-2xl bg-zinc-900 px-4 py-2 text-sm font-semibold text-white no-underline hover:bg-zinc-800">
                Browse materials
              </Link>
              <Link href="/study/practice" className="inline-flex items-center gap-2 rounded-2xl border bg-white px-4 py-2 text-sm font-semibold text-zinc-900 no-underline hover:bg-zinc-50">
                Practice mode
              </Link>
            </div>
          </div>
        ) : (
          visible.map((row) => {
            if (row.item_type === "material") {
              const m = row.material_id ? materialsById[row.material_id] : null;
              return (
                <div key={row.id} className="rounded-3xl border bg-white p-4 shadow-sm">
                  <div className="flex items-start justify-between gap-3">
                    <div className="min-w-0">
                      <p className="truncate text-base font-semibold text-zinc-900">{m?.title ?? "Material"}</p>
                      {m?.description ? <p className="mt-1 line-clamp-2 text-sm text-zinc-600">{m.description}</p> : null}
                      <p className="mt-2 text-xs font-semibold text-zinc-600">Saved {formatWhen(row.created_at)}</p>
                    </div>
                    <button
                      type="button"
                      onClick={() => removeItem(row)}
                      disabled={savingId === row.id}
                      className="inline-flex items-center gap-2 rounded-2xl border bg-white px-3 py-2 text-xs font-semibold text-zinc-900 hover:bg-zinc-50"
                    >
                      <Trash2 className="h-4 w-4" /> Remove
                    </button>
                  </div>

                  <div className="mt-4 flex items-center gap-2">
                    <Link
                      href="/study/materials"
                      className="inline-flex items-center justify-center gap-2 rounded-2xl border bg-white px-4 py-3 text-sm font-semibold text-zinc-900 no-underline hover:bg-zinc-50"
                    >
                      Open materials
                    </Link>
                    {m?.file_url ? (
                      <a
                        href={m.file_url}
                        target="_blank"
                        rel="noreferrer"
                        className="inline-flex flex-1 items-center justify-center gap-2 rounded-2xl border border-zinc-900 bg-zinc-900 px-4 py-3 text-sm font-semibold text-white no-underline hover:bg-zinc-800"
                      >
                        Open file
                      </a>
                    ) : null}
                  </div>
                </div>
              );
            }

            if (row.item_type === "practice_set") {
              const s = row.practice_set_id ? setsById[row.practice_set_id] : null;
              return (
                <div key={row.id} className="rounded-3xl border bg-white p-4 shadow-sm">
                  <div className="flex items-start justify-between gap-3">
                    <div className="min-w-0">
                      <p className="truncate text-base font-semibold text-zinc-900">{s?.title ?? "Practice set"}</p>
                      {s?.description ? <p className="mt-1 line-clamp-2 text-sm text-zinc-600">{s.description}</p> : null}
                      <p className="mt-2 text-xs font-semibold text-zinc-600">Saved {formatWhen(row.created_at)}</p>
                    </div>
                    <button
                      type="button"
                      onClick={() => removeItem(row)}
                      disabled={savingId === row.id}
                      className="inline-flex items-center gap-2 rounded-2xl border bg-white px-3 py-2 text-xs font-semibold text-zinc-900 hover:bg-zinc-50"
                    >
                      <Trash2 className="h-4 w-4" /> Remove
                    </button>
                  </div>

                  <div className="mt-4 flex items-center gap-2">
                    <Link
                      href="/study/practice"
                      className="inline-flex items-center justify-center gap-2 rounded-2xl border bg-white px-4 py-3 text-sm font-semibold text-zinc-900 no-underline hover:bg-zinc-50"
                    >
                      Practice home
                    </Link>
                    {row.practice_set_id ? (
                      <Link
                        href={`/study/practice/${encodeURIComponent(row.practice_set_id)}`}
                        className="inline-flex flex-1 items-center justify-center gap-2 rounded-2xl border border-zinc-900 bg-zinc-900 px-4 py-3 text-sm font-semibold text-white no-underline hover:bg-zinc-800"
                      >
                        Start
                      </Link>
                    ) : null}
                  </div>
                </div>
              );
            }

            // question
            const q = row.question_id ? questionsById[row.question_id] : null;
            return (
              <div key={row.id} className="rounded-3xl border bg-white p-4 shadow-sm">
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <p className="truncate text-base font-semibold text-zinc-900">{q?.title ?? "Question"}</p>
                    {q?.body ? <p className="mt-1 line-clamp-2 text-sm text-zinc-600">{q.body}</p> : null}
                    <p className="mt-2 text-xs font-semibold text-zinc-600">Saved {formatWhen(row.created_at)}</p>
                  </div>
                  <button
                    type="button"
                    onClick={() => removeItem(row)}
                    disabled={savingId === row.id}
                    className="inline-flex items-center gap-2 rounded-2xl border bg-white px-3 py-2 text-xs font-semibold text-zinc-900 hover:bg-zinc-50"
                  >
                    <Trash2 className="h-4 w-4" /> Remove
                  </button>
                </div>

                <div className="mt-4 flex items-center gap-2">
                  <Link
                    href="/study/questions"
                    className="inline-flex items-center justify-center gap-2 rounded-2xl border bg-white px-4 py-3 text-sm font-semibold text-zinc-900 no-underline hover:bg-zinc-50"
                  >
                    Questions
                  </Link>
                  {row.question_id ? (
                    <Link
                      href={`/study/questions/${encodeURIComponent(row.question_id)}`}
                      className="inline-flex flex-1 items-center justify-center gap-2 rounded-2xl border border-zinc-900 bg-zinc-900 px-4 py-3 text-sm font-semibold text-white no-underline hover:bg-zinc-800"
                    >
                      Open
                    </Link>
                  ) : null}
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}
