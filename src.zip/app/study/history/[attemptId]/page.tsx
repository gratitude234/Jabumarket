// app/study/history/[attemptId]/page.tsx
import AttemptReviewClient from "./AttemptReviewClient";

export const dynamic = "force-dynamic";

export default function AttemptReviewPage() {
  return <AttemptReviewClient />;
}
