"use client";

import Link from "next/link";
import { useEffect, useMemo, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import { supabase } from "@/lib/supabase";
import {
  ArrowLeft,
  ArrowRight,
  CheckCircle2,
  Loader2,
  RefreshCcw,
  XCircle,
  BookOpen,
} from "lucide-react";

function cn(...p: Array<string | false | null | undefined>) {
  return p.filter(Boolean).join(" ");
}

function normalize(v: string) {
  return v.trim().replace(/\s+/g, " ");
}

type AttemptRow = {
  id: string;
  user_id: string;
  set_id: string;
  status: string;
  started_at: string;
  submitted_at: string | null;
  score: number | null;
  total_questions: number | null;
  time_spent_seconds: number | null;
};

type SetRow = {
  id: string;
  title: string;
  description: string | null;
  course_code: string | null;
  level: string | null;
  time_limit_minutes: number | null;
};

type QuestionRow = {
  id: string;
  prompt: string;
  explanation: string | null;
  position: number | null;
};

type OptionRow = {
  id: string;
  question_id: string;
  text: string;
  is_correct: boolean;
  position: number | null;
};

export default function AttemptReviewClient() {
  const router = useRouter();
  const params = useParams<{ attemptId: string }>();
  const attemptId = String(params?.attemptId ?? "");

  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState<string | null>(null);
  const [attempt, setAttempt] = useState<AttemptRow | null>(null);
  const [setMeta, setSetMeta] = useState<SetRow | null>(null);
  const [questions, setQuestions] = useState<QuestionRow[]>([]);
  const [optionsByQ, setOptionsByQ] = useState<Record<string, OptionRow[]>>({});
  const [answers, setAnswers] = useState<Record<string, string>>({}); // qid -> optionId
  const [selectedQ, setSelectedQ] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      setLoading(true);
      setErr(null);
      try {
        if (!attemptId) throw new Error("Missing attempt id");

        const { data: auth } = await supabase.auth.getUser();
        const user = auth?.user;
        if (!user) {
          router.replace(`/login?next=${encodeURIComponent(`/study/history/${attemptId}`)}`);
          return;
        }

        // Attempt (must belong to user)
        const { data: att, error: attErr } = await supabase
          .from("study_practice_attempts")
          .select("id,user_id,set_id,status,started_at,submitted_at,score,total_questions,time_spent_seconds")
          .eq("id", attemptId)
          .eq("user_id", user.id)
          .maybeSingle();
        if (attErr) throw attErr;
        if (!att) throw new Error("Attempt not found");

        const setId = String((att as any).set_id);

        const { data: setData, error: setErr } = await supabase
          .from("study_quiz_sets")
          .select("id,title,description,course_code,level,time_limit_minutes")
          .eq("id", setId)
          .maybeSingle();
        if (setErr) throw setErr;

        const { data: qData, error: qErr } = await supabase
          .from("study_quiz_questions")
          .select("id,prompt,explanation,position")
          .eq("set_id", setId)
          .order("position", { ascending: true });
        if (qErr) throw qErr;
        const qs = (qData as any[] | null) ?? [];
        const qIds = qs.map((q) => String(q.id));

        let optData: any[] = [];
        if (qIds.length) {
          const { data: oData, error: oErr } = await supabase
            .from("study_quiz_options")
            .select("id,question_id,text,is_correct,position")
            .in("question_id", qIds)
            .order("position", { ascending: true });
          if (oErr) throw oErr;
          optData = (oData as any[] | null) ?? [];
        }

        const grouped: Record<string, OptionRow[]> = {};
        for (const o of optData) {
          const qid = String(o.question_id);
          if (!grouped[qid]) grouped[qid] = [];
          grouped[qid].push({
            id: String(o.id),
            question_id: qid,
            text: String(o.text ?? ""),
            is_correct: Boolean(o.is_correct),
            position: typeof o.position === "number" ? o.position : null,
          });
        }

        // Load saved answers
        const { data: aData } = await supabase
          .from("study_attempt_answers")
          .select("question_id,selected_option_id")
          .eq("attempt_id", attemptId);
        const aMap: Record<string, string> = {};
        (aData ?? []).forEach((r: any) => {
          if (r?.question_id && r?.selected_option_id) aMap[String(r.question_id)] = String(r.selected_option_id);
        });

        if (!cancelled) {
          setAttempt(att as any);
          setSetMeta(setData as any);
          setQuestions(
            qs.map((q) => ({
              id: String(q.id),
              prompt: String(q.prompt ?? ""),
              explanation: q.explanation ? String(q.explanation) : null,
              position: typeof q.position === "number" ? q.position : null,
            }))
          );
          setOptionsByQ(grouped);
          setAnswers(aMap);
          setSelectedQ(qIds[0] ?? null);
        }
      } catch (e: any) {
        if (!cancelled) setErr(e?.message ?? "Failed to load review");
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [attemptId, router]);

  const derived = useMemo(() => {
    const total = questions.length;
    let answered = 0;
    let correct = 0;
    let wrong = 0;
    const mistakes: string[] = [];

    for (const q of questions) {
      const chosenId = answers[q.id];
      if (!chosenId) continue;
      answered += 1;
      const chosen = (optionsByQ[q.id] ?? []).find((o) => o.id === chosenId);
      const ok = Boolean(chosen?.is_correct);
      if (ok) correct += 1;
      else {
        wrong += 1;
        mistakes.push(q.id);
      }
    }

    return { total, answered, correct, wrong, mistakes };
  }, [questions, answers, optionsByQ]);

  const selected = selectedQ ? questions.find((q) => q.id === selectedQ) ?? null : null;
  const selectedOpts = selected ? optionsByQ[selected.id] ?? [] : [];
  const chosenId = selected ? answers[selected.id] : undefined;
  const chosenOpt = selected ? selectedOpts.find((o) => o.id === chosenId) : null;
  const correctOpt = selected ? selectedOpts.find((o) => o.is_correct) : null;
  const isWrong = Boolean(chosenId && chosenOpt && !chosenOpt.is_correct);

  const headerCode = normalize(String(setMeta?.course_code ?? "")).toUpperCase();

  if (loading) {
    return (
      <div className="mx-auto w-full max-w-4xl px-4 pb-24 pt-6">
        <div className="rounded-3xl border bg-white p-6 shadow-sm">
          <div className="flex items-center gap-2 text-sm font-semibold text-zinc-700">
            <Loader2 className="h-4 w-4 animate-spin" /> Loading review…
          </div>
        </div>
      </div>
    );
  }

  if (err || !attempt || !setMeta) {
    return (
      <div className="mx-auto w-full max-w-4xl px-4 pb-24 pt-6">
        <button
          type="button"
          onClick={() => router.back()}
          className="inline-flex items-center gap-2 rounded-2xl border bg-white px-4 py-2 text-sm font-semibold text-zinc-900 hover:bg-zinc-50"
        >
          <ArrowLeft className="h-4 w-4" /> Back
        </button>
        <div className="mt-4 rounded-3xl border bg-white p-6 shadow-sm">
          <p className="text-sm font-semibold text-zinc-900">Couldn’t open review</p>
          <p className="mt-1 text-sm text-zinc-600">{err ?? "Missing data"}</p>
          <Link
            href="/study/history"
            className="mt-4 inline-flex items-center gap-2 rounded-2xl border bg-white px-4 py-2 text-sm font-semibold text-zinc-900 no-underline hover:bg-zinc-50"
          >
            Back to history <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="mx-auto w-full max-w-5xl px-4 pb-24 pt-6">
      <div className="flex items-center justify-between gap-3">
        <button
          type="button"
          onClick={() => router.back()}
          className="inline-flex items-center gap-2 rounded-2xl border bg-white px-4 py-2 text-sm font-semibold text-zinc-900 hover:bg-zinc-50"
        >
          <ArrowLeft className="h-4 w-4" /> Back
        </button>
        <div className="flex flex-wrap items-center gap-2">
          <Link
            href={`/study/practice/${encodeURIComponent(setMeta.id)}?attempt=${encodeURIComponent(attempt.id)}`}
            className="inline-flex items-center gap-2 rounded-2xl border bg-white px-4 py-2 text-sm font-semibold text-zinc-900 no-underline hover:bg-zinc-50"
            title="Open this attempt"
          >
            <RefreshCcw className="h-4 w-4" /> Open attempt
          </Link>
          <Link
            href={`/study/practice/${encodeURIComponent(setMeta.id)}`}
            className="inline-flex items-center gap-2 rounded-2xl border border-zinc-900 bg-zinc-900 px-4 py-2 text-sm font-semibold text-white no-underline hover:bg-zinc-800"
            title="Start a new attempt"
          >
            Retry set <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
      </div>

      <div className="mt-6 rounded-3xl border bg-white p-4 shadow-sm">
        <div className="flex flex-wrap items-center gap-2">
          <p className="text-lg font-extrabold tracking-tight text-zinc-900">{normalize(String(setMeta.title ?? "Practice"))}</p>
          {headerCode ? (
            <Link
              href={`/study/courses/${encodeURIComponent(headerCode)}`}
              className="rounded-full border bg-white px-3 py-1.5 text-xs font-extrabold text-zinc-800 no-underline hover:bg-zinc-50"
            >
              {headerCode}
            </Link>
          ) : null}
          {setMeta.level ? <span className="rounded-full border bg-white px-3 py-1.5 text-xs font-semibold text-zinc-700">{String(setMeta.level)}L</span> : null}
          <span
            className={cn(
              "rounded-full border px-3 py-1.5 text-xs font-extrabold",
              attempt.status === "submitted" ? "border-emerald-200 bg-emerald-50 text-emerald-700" : "border-amber-200 bg-amber-50 text-amber-700"
            )}
          >
            {attempt.status === "submitted" ? "Submitted" : "In progress"}
          </span>
        </div>
        {setMeta.description ? <p className="mt-2 text-sm text-zinc-600">{normalize(setMeta.description)}</p> : null}

        <div className="mt-3 flex flex-wrap gap-2">
          <span className="rounded-full border bg-white px-3 py-1.5 text-xs font-extrabold text-zinc-800">
            Score: {derived.correct}/{derived.total}
          </span>
          <span className="rounded-full border bg-white px-3 py-1.5 text-xs font-extrabold text-zinc-800">
            Wrong: {derived.wrong}
          </span>
          <span className="rounded-full border bg-white px-3 py-1.5 text-xs font-extrabold text-zinc-800">
            Answered: {derived.answered}/{derived.total}
          </span>
        </div>
      </div>

      <div className="mt-4 grid gap-4 lg:grid-cols-[320px,1fr]">
        {/* Left: mistakes list */}
        <div className="rounded-3xl border bg-white p-4 shadow-sm">
          <p className="text-sm font-extrabold text-zinc-900">Review mistakes</p>
          <p className="mt-1 text-xs font-semibold text-zinc-600">Tap any question to see the correct answer + explanation.</p>

          {derived.mistakes.length === 0 ? (
            <div className="mt-4 rounded-2xl border bg-emerald-50 p-4 text-emerald-800">
              <p className="text-sm font-extrabold">No mistakes 🎉</p>
              <p className="mt-1 text-xs font-semibold">You got everything correct in this attempt.</p>
            </div>
          ) : (
            <div className="mt-3 grid gap-2">
              {derived.mistakes.map((qid) => {
                const qIndex = questions.findIndex((q) => q.id === qid);
                const isActive = selectedQ === qid;
                return (
                  <button
                    key={qid}
                    type="button"
                    onClick={() => setSelectedQ(qid)}
                    className={cn(
                      "flex w-full items-start justify-between gap-3 rounded-2xl border px-3 py-3 text-left",
                      isActive ? "border-zinc-900 bg-zinc-900 text-white" : "border-zinc-200 bg-white text-zinc-900 hover:bg-zinc-50"
                    )}
                  >
                    <div className="min-w-0">
                      <p className="text-xs font-extrabold opacity-80">Question {qIndex + 1}</p>
                      <p className="mt-1 line-clamp-2 text-sm font-semibold">{normalize(questions[qIndex]?.prompt ?? "")}</p>
                    </div>
                    <XCircle className={cn("h-5 w-5", isActive ? "text-white" : "text-rose-600")} />
                  </button>
                );
              })}
            </div>
          )}

          <Link
            href="/study/history"
            className="mt-4 inline-flex w-full items-center justify-center gap-2 rounded-2xl border bg-white px-4 py-2 text-sm font-semibold text-zinc-900 no-underline hover:bg-zinc-50"
          >
            <BookOpen className="h-4 w-4" /> View all attempts
          </Link>
        </div>

        {/* Right: selected question detail */}
        <div className="rounded-3xl border bg-white p-5 shadow-sm">
          {!selected ? (
            <p className="text-sm text-zinc-600">Select a question to review.</p>
          ) : (
            <>
              <p className="text-xs font-extrabold text-zinc-600">Question</p>
              <p className="mt-2 whitespace-pre-wrap text-base font-semibold text-zinc-900">{normalize(selected.prompt)}</p>

              <div className="mt-4 grid gap-2">
                {selectedOpts.map((o, i) => {
                  const isChosen = chosenId === o.id;
                  const isCorrect = o.is_correct;
                  const showWrongChosen = isChosen && !isCorrect;

                  return (
                    <div
                      key={o.id}
                      className={cn(
                        "flex items-start gap-3 rounded-2xl border px-4 py-3",
                        isCorrect ? "border-emerald-200 bg-emerald-50" : "border-zinc-200 bg-white",
                        showWrongChosen ? "border-rose-200 bg-rose-50" : ""
                      )}
                    >
                      <div className="mt-0.5">
                        {isCorrect ? (
                          <CheckCircle2 className="h-5 w-5 text-emerald-700" />
                        ) : showWrongChosen ? (
                          <XCircle className="h-5 w-5 text-rose-700" />
                        ) : (
                          <div className="h-5 w-5 rounded-full border" />
                        )}
                      </div>
                      <div className="min-w-0">
                        <p className="whitespace-pre-wrap text-sm font-semibold text-zinc-900">
                          {String.fromCharCode(65 + i)}. {normalize(o.text)}
                        </p>
                        {isChosen ? (
                          <p className={cn("mt-1 text-xs font-extrabold", isCorrect ? "text-emerald-700" : "text-rose-700")}>
                            Your choice
                          </p>
                        ) : null}
                        {isCorrect ? <p className="mt-1 text-xs font-extrabold text-emerald-700">Correct answer</p> : null}
                      </div>
                    </div>
                  );
                })}
              </div>

              <div className="mt-4 rounded-2xl border bg-zinc-50 p-4">
                <p className="text-sm font-extrabold text-zinc-900">Explanation</p>
                <p className="mt-1 whitespace-pre-wrap text-sm font-semibold text-zinc-700">
                  {normalize(selected.explanation ?? "No explanation provided.")}
                </p>
              </div>

              {isWrong && correctOpt ? (
                <div className="mt-4 rounded-2xl border border-amber-200 bg-amber-50 p-4 text-amber-800">
                  <p className="text-sm font-extrabold">Quick fix</p>
                  <p className="mt-1 text-xs font-semibold">
                    The correct answer is <span className="font-extrabold">{normalize(correctOpt.text)}</span>. Read the explanation and try this set again.
                  </p>
                </div>
              ) : null}
            </>
          )}
        </div>
      </div>
    </div>
  );
}
