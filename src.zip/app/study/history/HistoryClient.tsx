"use client";

import Link from "next/link";
import { useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { supabase } from "@/lib/supabase";
import { ArrowLeft, ArrowRight, Loader2, Timer, Trophy } from "lucide-react";

import StudyTabs from "../_components/StudyTabs";
function cn(...p: Array<string | false | null | undefined>) {
  return p.filter(Boolean).join(" ");
}

function normalize(v: string) {
  return v.trim().replace(/\s+/g, " ");
}

function fmtTime(sec: number | null) {
  if (!sec || sec <= 0) return "—";
  const m = Math.floor(sec / 60);
  const s = sec % 60;
  return `${m}m ${String(s).padStart(2, "0")}s`;
}

type AttemptRow = {
  id: string;
  set_id: string;
  status: "in_progress" | "submitted" | "abandoned" | string;
  started_at: string;
  submitted_at: string | null;
  score: number | null;
  total_questions: number | null;
  time_spent_seconds: number | null;
};

type SetRow = {
  id: string;
  title: string;
  course_code: string | null;
  level: string | null;
};

export default function HistoryClient() {
  const router = useRouter();
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState<string | null>(null);
  const [attempts, setAttempts] = useState<AttemptRow[]>([]);
  const [setsById, setSetsById] = useState<Record<string, SetRow>>({});

  useEffect(() => {
    let cancelled = false;
    (async () => {
      setLoading(true);
      setErr(null);
      try {
        const { data: auth } = await supabase.auth.getUser();
        const user = auth?.user;
        if (!user) {
          router.replace(`/login?next=${encodeURIComponent("/study/history")}`);
          return;
        }

        const { data: aData, error: aErr } = await supabase
          .from("study_practice_attempts")
          .select("id,set_id,status,started_at,submitted_at,score,total_questions,time_spent_seconds")
          .eq("user_id", user.id)
          .order("started_at", { ascending: false })
          .limit(60);
        if (aErr) throw aErr;

        const rows = ((aData as any[]) ?? []).map((r) => ({
          id: String(r.id),
          set_id: String(r.set_id),
          status: String(r.status),
          started_at: String(r.started_at),
          submitted_at: r.submitted_at ? String(r.submitted_at) : null,
          score: typeof r.score === "number" ? r.score : null,
          total_questions: typeof r.total_questions === "number" ? r.total_questions : null,
          time_spent_seconds: typeof r.time_spent_seconds === "number" ? r.time_spent_seconds : null,
        })) as AttemptRow[];

        // Fetch set metadata in a second query (avoids schema-cache FK issues)
        const setIds = Array.from(new Set(rows.map((x) => x.set_id).filter(Boolean)));
        let setMap: Record<string, SetRow> = {};
        if (setIds.length) {
          const { data: sData, error: sErr } = await supabase
            .from("study_quiz_sets")
            .select("id,title,course_code,level")
            .in("id", setIds);
          if (!sErr) {
            (sData as any[] | null)?.forEach((s) => {
              setMap[String(s.id)] = {
                id: String(s.id),
                title: String(s.title ?? "Practice"),
                course_code: s.course_code ? String(s.course_code) : null,
                level: s.level ? String(s.level) : null,
              };
            });
          }
        }

        if (!cancelled) {
          setAttempts(rows);
          setSetsById(setMap);
        }
      } catch (e: any) {
        if (!cancelled) setErr(e?.message ?? "Failed to load history");
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [router]);

  const summary = useMemo(() => {
    const submitted = attempts.filter((a) => a.status === "submitted");
    const total = submitted.length;
    const avgPct =
      total === 0
        ? 0
        : Math.round(
            (submitted.reduce((sum, a) => {
              const pct = a.total_questions ? (100 * (a.score ?? 0)) / a.total_questions : 0;
              return sum + pct;
            }, 0) /
              total) *
              10
          ) / 10;
    return { total, avgPct };
  }, [attempts]);

  return (
    <div className="mx-auto w-full max-w-3xl px-4 pb-24 pt-6">
      
      {/* Study sub-nav (sticky on mobile) */}
      <StudyTabs />
<div className="flex items-center justify-between gap-3">
        <button
          type="button"
          onClick={() => router.back()}
          className="inline-flex items-center gap-2 rounded-2xl border bg-white px-4 py-2 text-sm font-semibold text-zinc-900 hover:bg-zinc-50"
        >
          <ArrowLeft className="h-4 w-4" /> Back
        </button>

        <Link
          href="/study/practice"
          className="inline-flex items-center gap-2 rounded-2xl border bg-white px-4 py-2 text-sm font-semibold text-zinc-900 no-underline hover:bg-zinc-50"
        >
          Practice Mode <ArrowRight className="h-4 w-4" />
        </Link>
      </div>

      <div className="mt-6 rounded-3xl border bg-white p-4 shadow-sm">
        <p className="text-lg font-extrabold tracking-tight text-zinc-900">Practice History</p>
        <p className="mt-1 text-sm text-zinc-600">Review past attempts, continue unfinished ones, and learn from mistakes.</p>

        <div className="mt-3 flex flex-wrap gap-2">
          <span className="inline-flex items-center gap-2 rounded-full border bg-white px-3 py-1.5 text-xs font-extrabold text-zinc-800">
            <Trophy className="h-4 w-4" /> {summary.total} submitted
          </span>
          <span className="inline-flex items-center gap-2 rounded-full border bg-white px-3 py-1.5 text-xs font-extrabold text-zinc-800">
            Avg score: {summary.avgPct}%
          </span>
        </div>
      </div>

      {loading ? (
        <div className="mt-4 rounded-3xl border bg-white p-6 shadow-sm">
          <div className="flex items-center gap-2 text-sm font-semibold text-zinc-700">
            <Loader2 className="h-4 w-4 animate-spin" /> Loading history…
          </div>
        </div>
      ) : err ? (
        <div className="mt-4 rounded-3xl border bg-white p-6 shadow-sm">
          <p className="text-sm font-semibold text-zinc-900">Couldn’t load history</p>
          <p className="mt-1 text-sm text-zinc-600">{err}</p>
        </div>
      ) : attempts.length === 0 ? (
        <div className="mt-4 rounded-3xl border bg-white p-6 shadow-sm">
          <p className="text-sm font-semibold text-zinc-900">No attempts yet</p>
          <p className="mt-1 text-sm text-zinc-600">Start a practice set and your attempts will show up here.</p>
          <Link
            href="/study/practice"
            className="mt-4 inline-flex items-center gap-2 rounded-2xl border border-zinc-900 bg-zinc-900 px-4 py-2 text-sm font-semibold text-white no-underline hover:bg-zinc-800"
          >
            Start practicing <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
      ) : (
        <div className="mt-4 grid gap-3">
          {attempts.map((a) => {
            const set = setsById[a.set_id];
            const title = set?.title ? normalize(set.title) : "Practice";
            const code = set?.course_code ? normalize(set.course_code).toUpperCase() : "";
            const total = a.total_questions ?? 0;
            const score = a.score ?? 0;
            const pct = total > 0 ? Math.round((100 * score) / total) : null;
            const isSubmitted = a.status === "submitted";
            const isInProgress = a.status === "in_progress";
            const href = isInProgress
              ? `/study/practice/${encodeURIComponent(a.set_id)}?attempt=${encodeURIComponent(a.id)}`
              : `/study/history/${encodeURIComponent(a.id)}`;

            return (
              <Link
                key={a.id}
                href={href}
                className="rounded-3xl border bg-white p-4 shadow-sm no-underline hover:bg-zinc-50"
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <p className="truncate text-sm font-extrabold text-zinc-900">{title}</p>
                    <div className="mt-1 flex flex-wrap items-center gap-2">
                      {code ? (
                        <span className="rounded-full border bg-white px-2.5 py-1 text-[11px] font-extrabold text-zinc-800">{code}</span>
                      ) : null}
                      {set?.level ? (
                        <span className="rounded-full border bg-white px-2.5 py-1 text-[11px] font-semibold text-zinc-700">{String(set.level)}L</span>
                      ) : null}
                      <span
                        className={cn(
                          "rounded-full border px-2.5 py-1 text-[11px] font-extrabold",
                          isSubmitted
                            ? "border-emerald-200 bg-emerald-50 text-emerald-700"
                            : isInProgress
                              ? "border-amber-200 bg-amber-50 text-amber-700"
                              : "border-zinc-200 bg-white text-zinc-700"
                        )}
                      >
                        {isSubmitted ? "Submitted" : isInProgress ? "In progress" : "Attempt"}
                      </span>
                    </div>
                  </div>

                  <div className="text-right">
                    {isSubmitted && pct !== null ? (
                      <p className="text-sm font-extrabold text-zinc-900">{pct}%</p>
                    ) : (
                      <p className="text-sm font-extrabold text-zinc-900">—</p>
                    )}
                    <p className="mt-0.5 inline-flex items-center justify-end gap-1 text-xs font-semibold text-zinc-600">
                      <Timer className="h-3.5 w-3.5" /> {fmtTime(a.time_spent_seconds)}
                    </p>
                  </div>
                </div>
              </Link>
            );
          })}
        </div>
      )}
    </div>
  );
}
