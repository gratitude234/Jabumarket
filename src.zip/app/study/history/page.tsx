// app/study/history/page.tsx
import HistoryClient from "./HistoryClient";

export const dynamic = "force-dynamic";

export default function PracticeHistoryPage() {
  return <HistoryClient />;
}
