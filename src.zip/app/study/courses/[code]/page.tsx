// app/study/courses/[code]/page.tsx
"use client";

import Link from "next/link";
import { useEffect, useMemo, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import { supabase } from "@/lib/supabase";
import { getWhatsAppLink } from "@/lib/whatsapp";
import {
  ArrowLeft,
  BookOpen,
  FileText,
  Loader2,
  MessageCircle,
  Phone,
  ShieldCheck,
  Sparkles,
  Star,
  Clock,
} from "lucide-react";

type MaterialType =
  | "past_question"
  | "handout"
  | "slides"
  | "note"
  | "timetable"
  | "other"
  | string;

type Course = {
  id: string;
  course_code: string;
  title: string | null;
  study_departments?: {
    id: string;
    name: string;
    faculty_id: string;
    study_faculties?: { id: string; name: string } | null;
  } | null;
};

type Material = {
  id: string;
  title: string | null;
  description: string | null;
  file_url: string | null;
  file_type: string | null;
  level: string | null;
  semester: string | null;
  session: string | null;
  created_at: string | null;
  downloads: number | null;
  material_type: MaterialType | null;
};

function cn(...parts: Array<string | false | null | undefined>) {
  return parts.filter(Boolean).join(" ");
}

function normalize(v: string) {
  return v.trim().replace(/\s+/g, " ");
}

function formatWhen(iso?: string | null) {
  if (!iso) return "";
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return "";
  return d.toLocaleDateString("en-NG", { year: "numeric", month: "short", day: "numeric" });
}

function labelType(t: string) {
  const m: Record<string, string> = {
    past_question: "Past Questions",
    handout: "Handouts",
    slides: "Slides",
    note: "Notes",
    timetable: "Timetables",
    other: "Other",
  };
  return m[t] ?? "Materials";
}

function typeIcon(t: string) {
  if (t === "past_question") return <Sparkles className="h-4 w-4" />;
  return <FileText className="h-4 w-4" />;
}

function MaterialRow({ m }: { m: Material }) {
  const title = normalize(String(m.title ?? "Untitled material")) || "Untitled material";
  const href = m.file_url || "#";
  const badge =
    m.file_type?.toLowerCase().includes("pdf") || (m.file_url ?? "").toLowerCase().includes(".pdf")
      ? "PDF"
      : m.file_type
      ? String(m.file_type).toUpperCase()
      : "FILE";

  const meta = [m.level ? `${m.level}L` : "", m.semester ? `${m.semester} sem` : "", m.session ? String(m.session) : ""].filter(
    Boolean
  );

  return (
    <div className="rounded-3xl border bg-white p-4 shadow-sm">
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <p className="truncate text-base font-semibold text-zinc-900">{title}</p>
          <p className="mt-1 line-clamp-2 text-sm text-zinc-600">{m.description || " "}</p>
          <div className="mt-2 flex flex-wrap items-center gap-2">
            <span className="rounded-full border bg-zinc-50 px-2 py-0.5 text-[11px] font-semibold text-zinc-700">
              {badge}
            </span>
            {meta.map((b) => (
              <span key={b} className="rounded-full border bg-white px-2 py-0.5 text-[11px] font-semibold text-zinc-700">
                {b}
              </span>
            ))}
            {m.created_at ? (
              <span className="inline-flex items-center gap-1 rounded-full border bg-white px-2 py-0.5 text-[11px] font-semibold text-zinc-700">
                <Clock className="h-3.5 w-3.5" />
                {formatWhen(m.created_at)}
              </span>
            ) : null}
          </div>
        </div>
        <div className="grid h-12 w-12 shrink-0 place-items-center rounded-2xl border bg-zinc-50">
          <FileText className="h-5 w-5 text-zinc-800" />
        </div>
      </div>

      <div className="mt-4 flex items-center gap-2">
        <a
          href={href}
          target="_blank"
          rel="noreferrer"
          className={cn(
            "inline-flex flex-1 items-center justify-center gap-2 rounded-2xl border px-4 py-3 text-sm font-semibold transition no-underline",
            href === "#"
              ? "cursor-not-allowed bg-zinc-100 text-zinc-500 border-zinc-200"
              : "bg-zinc-900 text-white border-zinc-900 hover:bg-zinc-800"
          )}
        >
          <BookOpen className="h-4 w-4" />
          Open
        </a>

        <Link
          href={`/study/report?material=${encodeURIComponent(String(m.id))}`}
          className="inline-flex items-center justify-center rounded-2xl border px-4 py-3 text-sm font-semibold text-zinc-900 no-underline hover:bg-zinc-50"
        >
          Report
        </Link>
      </div>

      {typeof m.downloads === "number" ? (
        <p className="mt-2 text-xs font-semibold text-zinc-600">{m.downloads.toLocaleString("en-NG")} downloads</p>
      ) : null}
    </div>
  );
}

function TutorMiniCard({ t, courseCode }: { t: any; courseCode: string }) {
  const name = normalize(String(t?.name ?? t?.full_name ?? t?.display_name ?? "Tutor"));
  const verified = Boolean(t?.verified);
  const phone = normalize(String(t?.phone ?? t?.whatsapp ?? t?.contact ?? ""));
  const location = normalize(String(t?.location ?? t?.campus ?? ""));
  const headline = normalize(String(t?.headline ?? t?.bio_headline ?? ""));

  const wa = getWhatsAppLink(
    phone,
    `Hi ${name}, I found you on Jabu Study. I need help with ${courseCode}.\n\nLevel: \nTopic: \nPreferred time: \nMode (online/physical): \n\nThanks!`
  );

  return (
    <div className="rounded-3xl border bg-white p-4 shadow-sm">
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <div className="flex flex-wrap items-center gap-2">
            <p className="truncate text-base font-semibold text-zinc-900">{name}</p>
            {verified ? (
              <span className="inline-flex items-center gap-1 rounded-full border border-emerald-200 bg-emerald-50 px-2 py-0.5 text-[11px] font-semibold text-emerald-700">
                <ShieldCheck className="h-3.5 w-3.5" /> Verified
              </span>
            ) : null}
            {typeof t?.rating === "number" ? (
              <span className="inline-flex items-center gap-1 rounded-full border bg-white px-2 py-0.5 text-[11px] font-semibold text-zinc-700">
                <Star className="h-3.5 w-3.5" /> {Number(t.rating).toFixed(1)}
              </span>
            ) : null}
          </div>
          {headline ? <p className="mt-1 line-clamp-2 text-sm text-zinc-600">{headline}</p> : null}
          {location ? <p className="mt-2 text-xs font-semibold text-zinc-600">{location}</p> : null}
        </div>
      </div>

      <div className="mt-4 grid grid-cols-2 gap-2">
        <a
          href={wa}
          target="_blank"
          rel="noreferrer"
          className="inline-flex items-center justify-center gap-2 rounded-2xl border border-zinc-900 bg-zinc-900 px-4 py-3 text-sm font-semibold text-white no-underline hover:bg-zinc-800"
        >
          <MessageCircle className="h-4 w-4" /> WhatsApp
        </a>
        <a
          href={phone ? `tel:${phone.replace(/\s+/g, "")}` : "#"}
          className={cn(
            "inline-flex items-center justify-center gap-2 rounded-2xl border px-4 py-3 text-sm font-semibold no-underline",
            phone
              ? "border-zinc-200 bg-white text-zinc-900 hover:bg-zinc-50"
              : "cursor-not-allowed bg-zinc-100 text-zinc-500 border-zinc-200"
          )}
        >
          <Phone className="h-4 w-4" /> Call
        </a>
      </div>
    </div>
  );
}

export default function CourseHubPage() {
  const router = useRouter();
  const params = useParams<{ code: string }>();

  const rawCode = Array.isArray((params as any)?.code) ? (params as any).code[0] : (params as any)?.code;
  const code = normalize(decodeURIComponent(String(rawCode ?? ""))).toUpperCase();

  const [course, setCourse] = useState<Course | null>(null);
  const [materials, setMaterials] = useState<Material[]>([]);
  const [tutors, setTutors] = useState<any[]>([]);
  const [practiceSets, setPracticeSets] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let mounted = true;

    async function run() {
      setLoading(true);
      setError(null);

      if (!code) {
        setError("Invalid course code.");
        setLoading(false);
        return;
      }

      const cRes = await supabase
        .from("study_courses")
        .select(
          `
          id,course_code,title,department_id,
          study_departments:department_id(id,name,faculty_id,study_faculties:faculty_id(id,name))
        `
        )
        .eq("course_code", code)
        .maybeSingle();

      if (!mounted) return;

      if (cRes.error) {
        setError(cRes.error.message);
        setLoading(false);
        return;
      }

      if (!cRes.data) {
        setCourse(null);
        setMaterials([]);
        setTutors([]);
        setPracticeSets([]);
        setLoading(false);
        return;
      }

      const courseRow = cRes.data as any as Course;
      setCourse(courseRow);

      const mRes = await supabase
        .from("study_materials")
        .select("id,title,description,file_url,file_type,level,session,semester,created_at,downloads,material_type")
        .eq("approved", true)
        .eq("course_id", courseRow.id)
        .order("downloads", { ascending: false, nullsFirst: false })
        .order("created_at", { ascending: false })
        .limit(250);

      if (!mounted) return;

      if (mRes.error) {
        setError(mRes.error.message);
        setLoading(false);
        return;
      }

      setMaterials(((mRes.data as any[]) ?? []).filter(Boolean));

      // Practice sets (CBT)
      const pRes = await supabase
        .from("study_quiz_sets")
        .select("id,title,description,course_code,level,time_limit_minutes,questions_count,created_at")
        .eq("published", true)
        .ilike("course_code", `${code}%`)
        .order("created_at", { ascending: false })
        .limit(8);

      if (!mounted) return;
      if (pRes.error) {
        setPracticeSets([]);
      } else {
        setPracticeSets(((pRes.data as any[]) ?? []).filter(Boolean));
      }

      const tRes = await supabase.from("study_tutors").select("*").limit(400);

      if (!mounted) return;

      if (tRes.error) {
        setTutors([]);
      } else {
        const list = ((tRes.data as any[]) ?? []).filter(Boolean);
        const codeN = code.toLowerCase();
        const filtered = list.filter((t) => {
          if (t?.active === false) return false;
          const c = t?.courses ?? t?.course_codes ?? t?.subjects ?? "";
          const hay = (Array.isArray(c) ? c.join(" ") : String(c)).toLowerCase();
          return hay.includes(codeN);
        });

        filtered.sort((a, b) => {
          const va = Boolean(a?.verified);
          const vb = Boolean(b?.verified);
          if (va !== vb) return vb ? 1 : -1;
          const ra = Number(a?.rating ?? 0);
          const rb = Number(b?.rating ?? 0);
          if (ra !== rb) return rb - ra;
          const da = new Date(a?.created_at ?? 0).getTime();
          const db = new Date(b?.created_at ?? 0).getTime();
          return db - da;
        });

        setTutors(filtered.slice(0, 12));
      }

      setLoading(false);
    }

    run();

    return () => {
      mounted = false;
    };
  }, [code]);

  const grouped = useMemo(() => {
    const map = new Map<string, Material[]>();
    for (const m of materials) {
      const key = String(m.material_type ?? "other");
      if (!map.has(key)) map.set(key, []);
      map.get(key)!.push(m);
    }

    const order = ["past_question", "note", "handout", "slides", "timetable", "other"];
    const entries = Array.from(map.entries());
    entries.sort((a, b) => {
      const ia = order.indexOf(a[0]);
      const ib = order.indexOf(b[0]);
      return (ia === -1 ? 999 : ia) - (ib === -1 ? 999 : ib);
    });
    return entries;
  }, [materials]);

  const dept = course?.study_departments?.name ?? "";
  const faculty = course?.study_departments?.study_faculties?.name ?? "";

  return (
    <main className="mx-auto w-full max-w-3xl px-4 pb-24 pt-6">
      <div className="flex items-center justify-between gap-3">
        <button
          type="button"
          onClick={() => router.back()}
          className="inline-flex items-center gap-2 rounded-2xl border bg-white px-3 py-2 text-sm font-semibold text-zinc-900 hover:bg-zinc-50"
        >
          <ArrowLeft className="h-4 w-4" /> Back
        </button>
        <Link
          href="/study/materials"
          className="inline-flex items-center gap-2 rounded-2xl border bg-white px-3 py-2 text-sm font-semibold text-zinc-900 no-underline hover:bg-zinc-50"
        >
          Browse all materials
        </Link>
      </div>

      <div className="mt-5 rounded-3xl border bg-white p-5 shadow-sm">
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div className="min-w-0">
            <p className="text-sm font-semibold text-zinc-600">Course Hub</p>
            <h1 className="mt-1 truncate text-2xl font-extrabold text-zinc-900">{code || "Course"}</h1>
            {course?.title ? <p className="mt-1 text-sm text-zinc-600">{course.title}</p> : null}
            {dept || faculty ? (
              <p className="mt-2 text-xs font-semibold text-zinc-600">
                {dept}
                {dept && faculty ? " • " : ""}
                {faculty}
              </p>
            ) : null}
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <span className="inline-flex items-center gap-2 rounded-full border bg-zinc-50 px-3 py-2 text-xs font-semibold text-zinc-700">
              {materials.length.toLocaleString("en-NG")} materials
            </span>
            <Link
              href={`/study/materials/upload?course_code=${encodeURIComponent(code)}`}
              className="inline-flex items-center gap-2 rounded-full border border-zinc-900 bg-zinc-900 px-3 py-2 text-xs font-semibold text-white no-underline hover:bg-zinc-800"
            >
              Upload for {code}
            </Link>
          </div>
        </div>

        {error ? (
          <div className="mt-4 rounded-2xl border border-red-200 bg-red-50 p-4 text-sm text-red-700">{error}</div>
        ) : null}

        {loading ? (
          <div className="mt-6 flex items-center justify-center gap-2 text-sm font-semibold text-zinc-700">
            <Loader2 className="h-4 w-4 animate-spin" /> Loading course hub…
          </div>
        ) : null}

        {!loading && !error && !course ? (
          <div className="mt-6 rounded-2xl border bg-zinc-50 p-4">
            <p className="text-sm font-semibold text-zinc-900">Course not found</p>
            <p className="mt-1 text-sm text-zinc-600">No course matches “{code}”.</p>
          </div>
        ) : null}
      </div>

      {!loading && course ? (
        <section className="mt-6">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-bold text-zinc-900">Materials</h2>
            <Link
              href={`/study/materials?q=${encodeURIComponent(code)}`}
              className="text-sm font-semibold text-zinc-700 no-underline hover:underline"
            >
              Search this course in library
            </Link>
          </div>

          {materials.length === 0 ? (
            <div className="mt-3 rounded-3xl border bg-white p-5 shadow-sm">
              <p className="text-sm font-semibold text-zinc-900">No materials yet</p>
              <p className="mt-1 text-sm text-zinc-600">Be the first to upload past questions, notes or slides for {code}.</p>
              <div className="mt-4">
                <Link
                  href={`/study/materials/upload?course_code=${encodeURIComponent(code)}`}
                  className="inline-flex items-center gap-2 rounded-2xl border border-zinc-900 bg-zinc-900 px-4 py-3 text-sm font-semibold text-white no-underline hover:bg-zinc-800"
                >
                  Upload material
                </Link>
              </div>
            </div>
          ) : (
            <div className="mt-3 space-y-5">
              {grouped.map(([t, list]) => (
                <div key={t} className="rounded-3xl border bg-white p-5 shadow-sm">
                  <div className="flex flex-wrap items-center justify-between gap-3">
                    <div className="flex items-center gap-2">
                      <span className="grid h-9 w-9 place-items-center rounded-2xl border bg-zinc-50 text-zinc-800">
                        {typeIcon(t)}
                      </span>
                      <div>
                        <p className="text-sm font-bold text-zinc-900">{labelType(t)}</p>
                        <p className="text-xs font-semibold text-zinc-600">{list.length.toLocaleString("en-NG")} item(s)</p>
                      </div>
                    </div>
                    <Link
                      href={`/study/materials?type=${encodeURIComponent(t)}&q=${encodeURIComponent(code)}`}
                      className="text-sm font-semibold text-zinc-700 no-underline hover:underline"
                    >
                      View in library
                    </Link>
                  </div>

                  <div className="mt-4 grid gap-3">
                    {list.slice(0, 6).map((m) => (
                      <MaterialRow key={m.id} m={m} />
                    ))}
                  </div>

                  {list.length > 6 ? (
                    <div className="mt-4">
                      <Link
                        href={`/study/materials?type=${encodeURIComponent(t)}&q=${encodeURIComponent(code)}`}
                        className="inline-flex items-center justify-center rounded-2xl border bg-white px-4 py-3 text-sm font-semibold text-zinc-900 no-underline hover:bg-zinc-50"
                      >
                        See more ({list.length - 6})
                      </Link>
                    </div>
                  ) : null}
                </div>
              ))}
            </div>
          )}
        </section>
      ) : null}

      {!loading && course ? (
        <section className="mt-8">
          <div className="flex items-center justify-between gap-3">
            <div>
              <h2 className="text-lg font-bold text-zinc-900">Practice (CBT)</h2>
              <p className="mt-1 text-sm text-zinc-600">Timed practice sets for {code}. Great for revision.</p>
            </div>
            <Link
              href={`/study/practice?course=${encodeURIComponent(code)}`}
              className="inline-flex items-center justify-center rounded-2xl border bg-white px-3 py-2 text-sm font-semibold text-zinc-900 no-underline hover:bg-zinc-50"
            >
              View all
            </Link>
          </div>

          {practiceSets.length === 0 ? (
            <div className="mt-3 rounded-3xl border bg-white p-5 shadow-sm">
              <p className="text-sm font-semibold text-zinc-900">No practice sets yet</p>
              <p className="mt-1 text-sm text-zinc-600">
                You can still download past questions in Materials. Admin/department can publish CBT sets for {code}.
              </p>
              <div className="mt-4">
                <Link
                  href={`/study/practice?course=${encodeURIComponent(code)}`}
                  className="inline-flex items-center justify-center rounded-2xl border bg-white px-4 py-3 text-sm font-semibold text-zinc-900 no-underline hover:bg-zinc-50"
                >
                  Go to Practice Mode
                </Link>
              </div>
            </div>
          ) : (
            <div className="mt-3 grid gap-3">
              {practiceSets.map((s: any) => (
                <Link
                  key={String(s.id)}
                  href={`/study/practice/${encodeURIComponent(String(s.id))}`}
                  className="block rounded-3xl border bg-white p-4 shadow-sm no-underline transition hover:bg-zinc-50"
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="min-w-0">
                      <p className="truncate text-base font-semibold text-zinc-900">{normalize(String(s.title ?? "Practice set"))}</p>
                      {s.description ? <p className="mt-1 line-clamp-2 text-sm text-zinc-600">{normalize(String(s.description))}</p> : null}
                      <div className="mt-2 flex flex-wrap items-center gap-2">
                        {typeof s.questions_count === "number" ? (
                          <span className="rounded-full border bg-zinc-50 px-2 py-0.5 text-[11px] font-semibold text-zinc-700">
                            {Number(s.questions_count).toLocaleString("en-NG")} questions
                          </span>
                        ) : null}
                        {typeof s.time_limit_minutes === "number" ? (
                          <span className="rounded-full border bg-zinc-50 px-2 py-0.5 text-[11px] font-semibold text-zinc-700">
                            {Number(s.time_limit_minutes)} mins
                          </span>
                        ) : null}
                        {s.level ? (
                          <span className="rounded-full border bg-white px-2 py-0.5 text-[11px] font-semibold text-zinc-700">{String(s.level)}L</span>
                        ) : null}
                      </div>
                    </div>
                    <div className="grid h-12 w-12 shrink-0 place-items-center rounded-2xl border bg-zinc-50">
                      <Sparkles className="h-5 w-5 text-zinc-800" />
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          )}
        </section>
      ) : null}

      {!loading && course ? (
        <section className="mt-8">
          <div className="flex items-center justify-between gap-3">
            <div>
              <h2 className="text-lg font-bold text-zinc-900">Q&amp;A for {code}</h2>
              <p className="mt-1 text-sm text-zinc-600">Ask questions, get answers, and learn faster.</p>
            </div>
            <div className="flex items-center gap-2">
              <Link
                href={`/study/questions?course=${encodeURIComponent(code)}`}
                className="inline-flex items-center justify-center rounded-2xl border bg-white px-3 py-2 text-sm font-semibold text-zinc-900 no-underline hover:bg-zinc-50"
              >
                View all
              </Link>
              <Link
                href={`/study/questions/ask?course=${encodeURIComponent(code)}`}
                className="inline-flex items-center justify-center rounded-2xl border border-zinc-900 bg-zinc-900 px-3 py-2 text-sm font-semibold text-white no-underline hover:bg-zinc-800"
              >
                Ask
              </Link>
            </div>
          </div>

          {questions.length === 0 ? (
            <div className="mt-3 rounded-3xl border bg-white p-5 shadow-sm">
              <p className="text-sm font-semibold text-zinc-900">No questions yet</p>
              <p className="mt-1 text-sm text-zinc-600">Be the first to ask a question about {code}.</p>
              <div className="mt-4">
                <Link
                  href={`/study/questions/ask?course=${encodeURIComponent(code)}`}
                  className="inline-flex items-center gap-2 rounded-2xl border border-zinc-900 bg-zinc-900 px-4 py-3 text-sm font-semibold text-white no-underline hover:bg-zinc-800"
                >
                  <MessageCircle className="h-4 w-4" /> Ask a question
                </Link>
              </div>
            </div>
          ) : (
            <div className="mt-3 space-y-3">
              {questions.map((q) => (
                <Link
                  key={q.id}
                  href={`/study/questions/${encodeURIComponent(String(q.id))}`}
                  className="block rounded-3xl border bg-white p-4 shadow-sm no-underline hover:bg-zinc-50"
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="min-w-0">
                      <p className="truncate text-base font-semibold text-zinc-900">{q.title}</p>
                      <div className="mt-2 flex flex-wrap items-center gap-2">
                        {q.solved ? (
                          <span className="rounded-full border border-emerald-200 bg-emerald-50 px-2 py-0.5 text-[11px] font-semibold text-emerald-700">
                            Solved
                          </span>
                        ) : (
                          <span className="rounded-full border bg-white px-2 py-0.5 text-[11px] font-semibold text-zinc-700">
                            Unsolved
                          </span>
                        )}
                        {q.level ? (
                          <span className="rounded-full border bg-white px-2 py-0.5 text-[11px] font-semibold text-zinc-700">
                            {q.level}L
                          </span>
                        ) : null}
                        <span className="rounded-full border bg-zinc-50 px-2 py-0.5 text-[11px] font-semibold text-zinc-700">
                          {(q.answers_count ?? 0).toLocaleString("en-NG")} answers
                        </span>
                        <span className="rounded-full border bg-zinc-50 px-2 py-0.5 text-[11px] font-semibold text-zinc-700">
                          {(q.upvotes_count ?? 0).toLocaleString("en-NG")} upvotes
                        </span>
                        {q.created_at ? (
                          <span className="inline-flex items-center gap-1 rounded-full border bg-white px-2 py-0.5 text-[11px] font-semibold text-zinc-700">
                            <Clock className="h-3.5 w-3.5" /> {formatWhen(q.created_at)}
                          </span>
                        ) : null}
                      </div>
                    </div>
                    <div className="grid h-12 w-12 shrink-0 place-items-center rounded-2xl border bg-zinc-50">
                      <MessageCircle className="h-5 w-5 text-zinc-800" />
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          )}
        </section>
      ) : null}

      {!loading && course ? (
        <section className="mt-8">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-bold text-zinc-900">Tutors for {code}</h2>
            <Link
              href={`/study/tutors?course=${encodeURIComponent(code)}`}
              className="text-sm font-semibold text-zinc-700 no-underline hover:underline"
            >
              Browse tutors
            </Link>
          </div>

          {tutors.length === 0 ? (
            <div className="mt-3 rounded-3xl border bg-white p-5 shadow-sm">
              <p className="text-sm font-semibold text-zinc-900">No tutors listed yet</p>
              <p className="mt-1 text-sm text-zinc-600">If you can tutor {code}, list yourself on the Tutors page.</p>
              <div className="mt-4">
                <Link
                  href="/study/tutors"
                  className="inline-flex items-center justify-center rounded-2xl border bg-white px-4 py-3 text-sm font-semibold text-zinc-900 no-underline hover:bg-zinc-50"
                >
                  Go to Tutors
                </Link>
              </div>
            </div>
          ) : (
            <div className="mt-3 grid gap-3">
              {tutors.map((t) => (
                <TutorMiniCard key={String(t.id ?? t.user_id ?? Math.random())} t={t} courseCode={code} />
              ))}
            </div>
          )}
        </section>
      ) : null}
    </main>
  );
}
