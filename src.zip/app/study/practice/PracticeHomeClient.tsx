// app/study/practice/PracticeHomeClient.tsx
"use client";

import Link from "next/link";
import { useEffect, useMemo, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { supabase } from "@/lib/supabase";
import {
  ArrowLeft,
  ArrowRight,
  BookOpen,
  Search,
  Sparkles,
  Timer,
  Bookmark,
  BookmarkCheck,
} from "lucide-react";

import { getAuthedUserId, toggleSaved } from "@/lib/studySaved";
import { getLatestAttempt, PracticeAttemptRow } from "@/lib/studyPractice";

import StudyTabs from "../_components/StudyTabs";
import { Card, EmptyState, PageHeader, SkeletonCard } from "../_components/StudyUI";
function cn(...parts: Array<string | false | null | undefined>) {
  return parts.filter(Boolean).join(" ");
}

type QuizSet = {
  id: string;
  title: string;
  description: string | null;
  course_code: string | null;
  level: string | null;
  time_limit_minutes: number | null;
  questions_count?: number | null;
  created_at?: string | null;
};

function normalize(v: string) {
  return v.trim().replace(/\s+/g, " ");
}

function formatWhen(iso?: string | null) {
  if (!iso) return "";
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return "";
  return d.toLocaleDateString("en-NG", { year: "numeric", month: "short", day: "numeric" });
}

export default function PracticeHomeClient() {
  const router = useRouter();
  const searchParams = useSearchParams();

  const presetCourse = normalize(String(searchParams.get("course") ?? ""));

  const [q, setQ] = useState(presetCourse);
  const [sets, setSets] = useState<QuizSet[]>([]);
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState<string | null>(null);

  const [savedIds, setSavedIds] = useState<Set<string>>(new Set());
  const [savingId, setSavingId] = useState<string | null>(null);

  const [latestAttempt, setLatestAttempt] = useState<PracticeAttemptRow | null>(null);
  const [latestSet, setLatestSet] = useState<QuizSet | null>(null);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const att = await getLatestAttempt();
        if (!cancelled) setLatestAttempt(att);
      } catch {
        if (!cancelled) setLatestAttempt(null);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  // Fetch set details for the latest attempt (for a richer "Continue" card)
  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        if (!latestAttempt?.set_id) {
          if (!cancelled) setLatestSet(null);
          return;
        }
        const { data, error } = await supabase
          .from("study_quiz_sets")
          .select("id,title,description,course_code,level,time_limit_minutes,questions_count,created_at")
          .eq("id", latestAttempt.set_id)
          .maybeSingle();
        if (error) throw error;
        if (!cancelled) setLatestSet((data as any) ?? null);
      } catch {
        if (!cancelled) setLatestSet(null);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [latestAttempt?.set_id]);

  const courseFilter = useMemo(() => {
    const v = normalize(q).toUpperCase();
    if (!v) return "";
    // keep only letters+numbers for course codes
    return v.replace(/[^A-Z0-9]/g, "");
  }, [q]);

  useEffect(() => {
    let cancelled = false;
    async function run() {
      setLoading(true);
      setErr(null);
      try {
        // fetch sets
        let query = supabase
          .from("study_quiz_sets")
          .select("id,title,description,course_code,level,time_limit_minutes,questions_count,created_at")
          .eq("published", true)
          .order("created_at", { ascending: false })
          .limit(100);

        if (courseFilter) {
          query = query.ilike("course_code", `${courseFilter}%`);
        }

        const { data, error } = await query;
        if (error) throw error;

        if (!cancelled) setSets((data as any) ?? []);
      } catch (e: any) {
        if (!cancelled) setErr(e?.message ?? "Failed to load practice sets");
      } finally {
        if (!cancelled) setLoading(false);
      }
    }
    run();
    return () => {
      cancelled = true;
    };
  }, [courseFilter]);

  // Load saved practice-set ids for visible list
  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const userId = await getAuthedUserId();
        if (!userId) {
          if (!cancelled) setSavedIds(new Set());
          return;
        }
        const ids = sets.map((s) => s.id).filter(Boolean);
        if (ids.length === 0) {
          if (!cancelled) setSavedIds(new Set());
          return;
        }
        const { data, error } = await supabase
          .from("study_saved_items")
          .select("practice_set_id")
          .eq("user_id", userId)
          .eq("item_type", "practice_set")
          .in("practice_set_id", ids);
        if (error) throw error;
        const next = new Set<string>();
        (data ?? []).forEach((r: any) => {
          if (r?.practice_set_id) next.add(String(r.practice_set_id));
        });
        if (!cancelled) setSavedIds(next);
      } catch {
        if (!cancelled) setSavedIds(new Set());
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [sets]);

  async function onToggleSetSave(setId: string) {
    setSavingId(setId);
    setSavedIds((prev) => {
      const n = new Set(prev);
      if (n.has(setId)) n.delete(setId);
      else n.add(setId);
      return n;
    });
    try {
      await toggleSaved({ itemType: "practice_set", practiceSetId: setId });
    } catch (e: any) {
      // revert
      setSavedIds((prev) => {
        const n = new Set(prev);
        if (n.has(setId)) n.delete(setId);
        else n.add(setId);
        return n;
      });
      alert(e?.message ?? "Could not save. Try again.");
    } finally {
      setSavingId(null);
    }
  }

  return (
    <div className="mx-auto w-full max-w-3xl px-4 pb-24 pt-6">
      {/* Study sub-nav (sticky on mobile) */}
      <StudyTabs />
      <div className="mt-3">
        <Card className="rounded-3xl">
          <PageHeader
            title="Practice"
            subtitle="Timed CBT-style practice sets (admin/department can publish sets)."
            right={
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => router.back()}
                  className="inline-flex items-center gap-2 rounded-2xl border bg-background px-3 py-2 text-sm font-semibold text-foreground hover:bg-secondary/50"
                >
                  <ArrowLeft className="h-4 w-4" /> Back
                </button>
                <Link
                  href="/study/history"
                  className="inline-flex items-center gap-2 rounded-2xl border bg-background px-3 py-2 text-sm font-semibold text-foreground no-underline hover:bg-secondary/50"
                >
                  History <ArrowRight className="h-4 w-4" />
                </Link>
              </div>
            }
          />
        </Card>
      </div>

      <div className="mt-4">
        <Card className="rounded-3xl">
          <p className="text-sm font-semibold text-foreground">Find a course</p>
          <div className="mt-3 flex items-center gap-2 rounded-2xl border bg-background px-3 py-2">
          <Search className="h-4 w-4 text-zinc-500" />
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Type course code e.g. GST101"
            className="w-full bg-transparent text-sm font-semibold text-zinc-900 outline-none placeholder:text-zinc-400"
          />
          {courseFilter ? (
            <button
              type="button"
              onClick={() => setQ("")}
              className="rounded-xl border bg-white px-3 py-1.5 text-xs font-semibold text-zinc-700 hover:bg-zinc-50"
            >
              Clear
            </button>
          ) : null}
        </div>
          <p className="mt-2 text-xs font-semibold text-muted-foreground">
          Tip: Use your course code (like <span className="font-extrabold">CSC201</span>). If you don’t see sets yet, ask your
          course rep/admin to publish.
          </p>
        </Card>
      </div>

      {latestAttempt ? (
        <div className="mt-4">
          <Card className="rounded-3xl">
            <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
              <div className="min-w-0">
                <div className="flex flex-wrap items-center gap-2">
                  <p className="text-sm font-semibold text-foreground">Continue</p>
                  <span
                    className={cn(
                      "rounded-full border px-2 py-0.5 text-[11px] font-extrabold",
                      latestAttempt.status === "in_progress"
                        ? "border-zinc-900 bg-zinc-900 text-white"
                        : "border-zinc-200 bg-white text-zinc-800"
                    )}
                  >
                    {latestAttempt.status === "in_progress" ? "IN PROGRESS" : "LAST ATTEMPT"}
                  </span>
                </div>

                <p className="mt-2 truncate text-base font-semibold text-foreground">
                  {latestSet?.title ? normalize(String(latestSet.title)) : "Practice set"}
                </p>

                <div className="mt-2 flex flex-wrap items-center gap-2">
                  {latestSet?.course_code ? (
                    <span className="rounded-full border bg-white px-2 py-0.5 text-[11px] font-extrabold text-zinc-800">
                      {normalize(String(latestSet.course_code)).toUpperCase()}
                    </span>
                  ) : null}
                  {latestSet?.level ? (
                    <span className="rounded-full border bg-white px-2 py-0.5 text-[11px] font-semibold text-zinc-700">
                      {String(latestSet.level)}L
                    </span>
                  ) : null}
                  {typeof latestSet?.time_limit_minutes === "number" ? (
                    <span className="inline-flex items-center gap-1 rounded-full border bg-zinc-50 px-2 py-0.5 text-[11px] font-semibold text-zinc-700">
                      <Timer className="h-3.5 w-3.5" /> {latestSet.time_limit_minutes} mins
                    </span>
                  ) : null}
                  {typeof latestSet?.questions_count === "number" ? (
                    <span className="inline-flex items-center gap-1 rounded-full border bg-zinc-50 px-2 py-0.5 text-[11px] font-semibold text-zinc-700">
                      <Sparkles className="h-3.5 w-3.5" /> {latestSet.questions_count} questions
                    </span>
                  ) : null}
                </div>

                <p className="mt-2 text-sm text-muted-foreground">
                  {latestAttempt.status === "in_progress"
                    ? "You have an in-progress attempt."
                    : typeof latestAttempt.score === "number" && typeof latestAttempt.total_questions === "number"
                    ? `Last score: ${latestAttempt.score}/${latestAttempt.total_questions}`
                    : "Your last attempt is saved."}
                </p>
              </div>

              <div className="flex flex-wrap gap-2">
                <Link
                  href={
                    latestAttempt.status === "in_progress"
                      ? `/study/practice/${encodeURIComponent(latestAttempt.set_id)}?attempt=${encodeURIComponent(
                          latestAttempt.id
                        )}`
                      : `/study/history/${encodeURIComponent(latestAttempt.id)}`
                  }
                  className="inline-flex items-center justify-center gap-2 rounded-2xl border border-zinc-900 bg-zinc-900 px-4 py-3 text-sm font-semibold text-white no-underline hover:bg-zinc-800"
                >
                  {latestAttempt.status === "in_progress" ? "Resume" : "Review"} <ArrowRight className="h-4 w-4" />
                </Link>
                <Link
                  href={`/study/practice/${encodeURIComponent(latestAttempt.set_id)}`}
                  className="inline-flex items-center justify-center gap-2 rounded-2xl border bg-white px-4 py-3 text-sm font-semibold text-zinc-900 no-underline hover:bg-zinc-50"
                >
                  Retry
                </Link>
              </div>
            </div>
          </Card>
        </div>
      ) : null}

      <div className="mt-6 flex items-end justify-between gap-3">
        <div>
          <p className="text-base font-semibold text-zinc-900">Available sets</p>
          <p className="mt-1 text-sm text-zinc-600">
            {courseFilter ? `Showing sets for ${courseFilter}` : "Showing latest published sets"}
          </p>
        </div>
        <Link
          href="/study/materials"
          className="inline-flex items-center gap-2 rounded-2xl border bg-white px-4 py-2 text-sm font-semibold text-zinc-900 no-underline hover:bg-zinc-50"
        >
          Browse materials <ArrowRight className="h-4 w-4" />
        </Link>
      </div>

      <div className="mt-4 grid gap-3">
        {loading ? (
          <>
            {Array.from({ length: 4 }).map((_, i) => (
              <SkeletonCard key={i} className="rounded-3xl" />
            ))}
          </>
        ) : err ? (
          <EmptyState title="Couldn’t load practice sets" description={err} />
        ) : sets.length === 0 ? (
          <EmptyState
            title="No practice sets yet"
            description="You can still use past questions in Materials. When you’re ready, ask your admin/course rep to publish sets."
            action={
              <Link
                className="inline-flex items-center gap-2 rounded-2xl border bg-background px-4 py-2 text-sm font-semibold text-foreground no-underline hover:bg-secondary/50"
                href="/study/materials"
              >
                Browse materials <ArrowRight className="h-4 w-4" />
              </Link>
            }
          />
        ) : (
          sets.map((s) => {
            const code = normalize(String(s.course_code ?? "")).toUpperCase();
            const title = normalize(String(s.title ?? "Practice set")) || "Practice set";
            const desc = normalize(String(s.description ?? ""));
            const limit = typeof s.time_limit_minutes === "number" ? s.time_limit_minutes : null;
            const qn = typeof s.questions_count === "number" ? s.questions_count : null;
            const saved = savedIds.has(s.id);
            const saving = savingId === s.id;
            return (
              <Card key={s.id} className="rounded-3xl">
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <div className="flex flex-wrap items-center gap-2">
                      <p className="truncate text-base font-semibold text-zinc-900">{title}</p>
                      {code ? (
                        <span className="rounded-full border bg-white px-2 py-0.5 text-[11px] font-extrabold text-zinc-800">
                          {code}
                        </span>
                      ) : null}
                      {s.level ? (
                        <span className="rounded-full border bg-white px-2 py-0.5 text-[11px] font-semibold text-zinc-700">
                          {String(s.level)}L
                        </span>
                      ) : null}
                    </div>
                    {desc ? <p className="mt-1 line-clamp-2 text-sm text-zinc-600">{desc}</p> : null}
                    <div className="mt-2 flex flex-wrap items-center gap-2">
                      {limit ? (
                        <span className="inline-flex items-center gap-1 rounded-full border bg-zinc-50 px-2 py-0.5 text-[11px] font-semibold text-zinc-700">
                          <Timer className="h-3.5 w-3.5" /> {limit} mins
                        </span>
                      ) : null}
                      {qn ? (
                        <span className="inline-flex items-center gap-1 rounded-full border bg-zinc-50 px-2 py-0.5 text-[11px] font-semibold text-zinc-700">
                          <Sparkles className="h-3.5 w-3.5" /> {qn} questions
                        </span>
                      ) : null}
                      {s.created_at ? (
                        <span className="rounded-full border bg-white px-2 py-0.5 text-[11px] font-semibold text-zinc-700">
                          {formatWhen(s.created_at)}
                        </span>
                      ) : null}
                    </div>
                  </div>
                  <div className="grid h-12 w-12 shrink-0 place-items-center rounded-2xl border bg-zinc-50">
                    <BookOpen className="h-5 w-5 text-zinc-800" />
                  </div>
                </div>

                <div className="mt-4 flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => onToggleSetSave(s.id)}
                    disabled={saving}
                    className={cn(
                      "inline-flex items-center justify-center gap-2 rounded-2xl border px-3 py-3 text-sm font-semibold transition",
                      saved
                        ? "border-zinc-900 bg-zinc-900 text-white hover:bg-zinc-800"
                        : "border-zinc-200 bg-white text-zinc-900 hover:bg-zinc-50",
                      saving ? "opacity-70" : ""
                    )}
                    aria-label={saved ? "Unsave practice set" : "Save practice set"}
                    title={saved ? "Saved" : "Save"}
                  >
                    {saved ? <BookmarkCheck className="h-4 w-4" /> : <Bookmark className="h-4 w-4" />}
                    <span className="hidden sm:inline">{saved ? "Saved" : "Save"}</span>
                  </button>

                  <Link
                    href={`/study/practice/${encodeURIComponent(s.id)}`}
                    className="inline-flex flex-1 items-center justify-center gap-2 rounded-2xl border border-zinc-900 bg-zinc-900 px-4 py-3 text-sm font-semibold text-white no-underline hover:bg-zinc-800"
                  >
                    Start practice <ArrowRight className="h-4 w-4" />
                  </Link>
                </div>
              </Card>
            );
          })
        )}
      </div>

      <div className="mt-8 rounded-3xl border bg-white p-4 text-sm text-zinc-700 shadow-sm">
        <p className="font-semibold text-zinc-900">Admin / Department note</p>
        <p className="mt-1">
          Practice Mode reads from <code className="px-1">study_quiz_sets</code>, <code className="px-1">study_quiz_questions</code> and
          <code className="px-1">study_quiz_options</code>. Publish a set by setting <code className="px-1">published=true</code>.
        </p>
      </div>
    </div>
  );
}
