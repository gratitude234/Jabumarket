// app/study/practice/page.tsx
import PracticeHomeClient from "./PracticeHomeClient";

export const dynamic = "force-dynamic";

export default function PracticePage() {
  return <PracticeHomeClient />;
}
