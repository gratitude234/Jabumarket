"use client";

import { useEffect, useMemo, useState } from "react";
import { Flag } from "lucide-react";
import { Card } from "@/app/study/_components/StudyUI";
import OptionCard from "../parts/OptionCard";
import ResponsePanel from "../parts/ResponsePanel";
import { cn, normalize, QuizOption, QuizQuestion } from "../usePracticeEngine";

function readAutoReveal() {
  if (typeof window === "undefined") return true;
  try {
    const raw = window.localStorage.getItem("jabu:practiceAutoReveal");
    if (raw === "0") return false;
    if (raw === "1") return true;
  } catch {
    // ignore
  }
  return true;
}

export default function InteractiveRunner({
  idx,
  total,
  current,
  opts,
  answers,
  flagged,
  submitted,
  onChoose,
  onToggleFlag,
  onNext,
}: {
  idx: number;
  total: number;
  current: QuizQuestion;
  opts: QuizOption[];
  answers: Record<string, string>;
  flagged: Record<string, boolean>;
  submitted: boolean;
  onChoose: (qid: string, oid: string) => void;
  onToggleFlag: (qid: string) => void;
  onNext: () => void;
}) {
  const chosenId = answers[current.id] ?? null;
  const [autoReveal, setAutoReveal] = useState(true);

  useEffect(() => {
    setAutoReveal(readAutoReveal());
  }, []);

  function toggleAuto(v: boolean) {
    setAutoReveal(v);
    try {
      window.localStorage.setItem("jabu:practiceAutoReveal", v ? "1" : "0");
    } catch {
      // ignore
    }
  }

  const hasAnswered = !!chosenId;
  const isLast = idx >= total - 1;

  const correct = useMemo(() => opts.find((o) => o.is_correct) ?? null, [opts]);
  const chosen = useMemo(() => (chosenId ? opts.find((o) => o.id === chosenId) ?? null : null), [chosenId, opts]);
  const state = !chosen ? "idle" : chosen.is_correct ? "correct" : "wrong";

  return (
    <div className="space-y-3">
      <Card className="rounded-3xl">
        <div className="flex items-start justify-between gap-3">
          <div className="min-w-0">
            <p className="text-xs font-extrabold text-muted-foreground">
              Question {idx + 1} of {total}
            </p>
            <p className="mt-2 whitespace-pre-wrap text-base font-semibold text-foreground">
              {normalize(String(current?.prompt ?? ""))}
            </p>
          </div>

          <button
            type="button"
            onClick={() => onToggleFlag(current.id)}
            className={cn(
              "inline-flex items-center gap-2 rounded-2xl border px-3 py-2 text-xs font-extrabold",
              flagged[current.id]
                ? "border-border bg-secondary text-foreground"
                : "border-border bg-background text-foreground hover:bg-secondary/50"
            )}
            title="Flag this question"
            aria-label="Flag this question"
            disabled={submitted}
          >
            <Flag className="h-4 w-4" /> {flagged[current.id] ? "Flagged" : "Flag"}
          </button>
        </div>

        <div className="mt-4 grid gap-2">
          {opts.map((o, i) => {
            const chosen = answers[current.id] === o.id;
            const label = String.fromCharCode(65 + i);

            const rightHint =
              hasAnswered && autoReveal ? (
                o.is_correct ? (
                  <span className="rounded-full border border-emerald-300/40 bg-emerald-100/30 px-2 py-1 text-[10px] font-extrabold text-foreground dark:bg-emerald-950/20">
                    Correct
                  </span>
                ) : chosen ? (
                  <span className="rounded-full border border-rose-300/40 bg-rose-100/30 px-2 py-1 text-[10px] font-extrabold text-foreground dark:bg-rose-950/20">
                    Your pick
                  </span>
                ) : null
              ) : null;

            return (
              <OptionCard
                key={o.id}
                label={label}
                text={String(o.text ?? "")}
                chosen={chosen}
                disabled={submitted}
                onClick={() => onChoose(current.id, o.id)}
                rightHint={rightHint}
              />
            );
          })}
        </div>

        {hasAnswered ? (
          <div className="mt-4 rounded-2xl border border-border bg-background p-3">
            <div className="flex items-start justify-between gap-3">
              <div className="min-w-0">
                <p className="text-xs font-extrabold text-muted-foreground">STATUS</p>
                <p className="mt-1 text-sm font-extrabold text-foreground">
                  {state === "correct" ? "✅ Correct" : state === "wrong" ? "❌ Not quite" : ""}
                </p>
                {state === "wrong" && correct ? (
                  <p className="mt-1 text-sm text-muted-foreground">
                    Correct answer: <span className="font-semibold text-foreground">{normalize(correct.text)}</span>
                  </p>
                ) : null}
              </div>

              <button
                type="button"
                onClick={onNext}
                className={cn(
                  "shrink-0 inline-flex items-center gap-2 rounded-2xl bg-secondary px-4 py-2 text-sm font-extrabold text-foreground",
                  "hover:opacity-90 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2",
                  isLast ? "opacity-80" : ""
                )}
                disabled={submitted}
              >
                {isLast ? "Finish" : "Next"}
              </button>
            </div>
          </div>
        ) : (
          <div className="mt-4 text-xs text-muted-foreground">
            Pick an option. You’ll see feedback instantly, then you can tap Next.
          </div>
        )}
      </Card>

      <ResponsePanel
        explanation={current.explanation}
        chosenOptionId={chosenId}
        options={opts}
        autoReveal={autoReveal}
        onToggleAutoReveal={toggleAuto}
      />
    </div>
  );
}
