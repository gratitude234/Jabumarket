"use client";

import { X } from "lucide-react";
import { cn } from "../usePracticeEngine";

function Sheet({
  open,
  title,
  subtitle,
  children,
  onClose,
}: {
  open: boolean;
  title: string;
  subtitle?: string;
  children: React.ReactNode;
  onClose: () => void;
}) {
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-[70]">
      <div className="absolute inset-0 bg-black/40 backdrop-blur-sm" onClick={onClose} />
      <div className="absolute inset-x-0 bottom-0 mx-auto w-full max-w-3xl p-3 sm:inset-0 sm:flex sm:items-center sm:justify-center sm:p-6">
        <div className="w-full rounded-3xl border border-border bg-card p-4 shadow-xl sm:p-5">
          <div className="flex items-start justify-between gap-3">
            <div className="min-w-0">
              <p className="text-base font-extrabold tracking-tight text-foreground">{title}</p>
              {subtitle ? <p className="mt-1 text-sm text-muted-foreground">{subtitle}</p> : null}
            </div>
            <button
              type="button"
              onClick={onClose}
              className="rounded-2xl p-2 hover:bg-secondary/60 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-card"
              aria-label="Close"
            >
              <X className="h-5 w-5" />
            </button>
          </div>
          <div className="mt-4">{children}</div>
        </div>
      </div>
    </div>
  );
}

export default function PaletteSheet({
  open,
  onClose,
  questions,
  activeIndex,
  answers,
  flagged,
  onJump,
  footer,
}: {
  open: boolean;
  onClose: () => void;
  questions: Array<{ id: string }>;
  activeIndex: number;
  answers: Record<string, string>;
  flagged: Record<string, boolean>;
  onJump: (i: number) => void;
  footer?: React.ReactNode;
}) {
  return (
    <Sheet
      open={open}
      title="Questions"
      subtitle="Tap any number to jump. Green = answered, 🚩 = flagged."
      onClose={onClose}
    >
      <div className="grid grid-cols-6 gap-2 sm:grid-cols-10">
        {questions.map((q, i) => {
          const isAnswered = !!answers[q.id];
          const isFlagged = !!flagged[q.id];
          const isActive = i === activeIndex;

          return (
            <button
              key={q.id}
              type="button"
              onClick={() => onJump(i)}
              className={cn(
                "relative rounded-2xl border px-0 py-2 text-sm font-extrabold",
                "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-card",
                isActive
                  ? "border-border bg-secondary text-foreground"
                  : isAnswered
                  ? "border-emerald-300/40 bg-emerald-100/30 text-foreground dark:bg-emerald-950/20"
                  : "border-border bg-background text-foreground hover:bg-secondary/50"
              )}
              aria-current={isActive ? "step" : undefined}
              aria-label={`Question ${i + 1}`}
            >
              {i + 1}
              {isFlagged ? <span className="absolute -right-1 -top-1 text-xs">🚩</span> : null}
            </button>
          );
        })}
      </div>

      {footer ? <div className="mt-4">{footer}</div> : null}
    </Sheet>
  );
}
