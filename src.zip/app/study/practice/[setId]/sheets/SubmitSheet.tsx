"use client";

import { X, Send } from "lucide-react";
import { cn } from "../usePracticeEngine";

function Sheet({
  open,
  title,
  subtitle,
  children,
  onClose,
}: {
  open: boolean;
  title: string;
  subtitle?: string;
  children: React.ReactNode;
  onClose: () => void;
}) {
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-[70]">
      <div className="absolute inset-0 bg-black/40 backdrop-blur-sm" onClick={onClose} />
      <div className="absolute inset-x-0 bottom-0 mx-auto w-full max-w-3xl p-3 sm:inset-0 sm:flex sm:items-center sm:justify-center sm:p-6">
        <div className="w-full rounded-3xl border border-border bg-card p-4 shadow-xl sm:p-5">
          <div className="flex items-start justify-between gap-3">
            <div className="min-w-0">
              <p className="text-base font-extrabold tracking-tight text-foreground">{title}</p>
              {subtitle ? <p className="mt-1 text-sm text-muted-foreground">{subtitle}</p> : null}
            </div>
            <button
              type="button"
              onClick={onClose}
              className="rounded-2xl p-2 hover:bg-secondary/60 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-card"
              aria-label="Close"
            >
              <X className="h-5 w-5" />
            </button>
          </div>
          <div className="mt-4">{children}</div>
        </div>
      </div>
    </div>
  );
}

export default function SubmitSheet({
  open,
  onClose,
  answered,
  total,
  onSubmit,
}: {
  open: boolean;
  onClose: () => void;
  answered: number;
  total: number;
  onSubmit: () => void;
}) {
  const remaining = Math.max(0, total - answered);

  return (
    <Sheet
      open={open}
      title="Submit attempt?"
      subtitle="You can still review your answers after submitting."
      onClose={onClose}
    >
      <div className="rounded-3xl border border-border bg-card p-4">
        <p className="text-sm font-semibold text-foreground">
          Answered: <span className="font-extrabold">{answered}</span> / {total}
        </p>
        {remaining ? (
          <p className="mt-1 text-sm text-muted-foreground">
            You have <span className="font-extrabold text-foreground">{remaining}</span> unanswered questions.
          </p>
        ) : null}

        <div className="mt-4 flex flex-wrap gap-2">
          <button
            type="button"
            onClick={onClose}
            className={cn(
              "inline-flex items-center gap-2 rounded-2xl border border-border bg-background px-4 py-2 text-sm font-extrabold text-foreground",
              "hover:bg-secondary/50 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
            )}
          >
            Keep working
          </button>

          <button
            type="button"
            onClick={onSubmit}
            className={cn(
              "ml-auto inline-flex items-center gap-2 rounded-2xl bg-secondary px-4 py-2 text-sm font-extrabold text-foreground",
              "hover:opacity-90 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
            )}
          >
            <Send className="h-4 w-4" /> Submit now
          </button>
        </div>
      </div>
    </Sheet>
  );
}
