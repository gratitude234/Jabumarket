// app/study/practice/[setId]/page.tsx
import PracticeTakeClient from "./PracticeTakeClient";

export const dynamic = "force-dynamic";

export default function PracticeTakePage() {
  return <PracticeTakeClient />;
}
