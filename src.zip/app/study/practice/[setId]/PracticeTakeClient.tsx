// app/study/practice/[setId]/PracticeTakeClient.tsx
"use client";

import Link from "next/link";
import { useEffect, useMemo, useRef, useState } from "react";
import { useParams, useRouter, useSearchParams } from "next/navigation";
import { supabase } from "@/lib/supabase";
import {
  ArrowLeft,
  ArrowRight,
  CheckCircle2,
  Circle,
  Flag,
  Loader2,
  RefreshCcw,
  Timer,
  XCircle,
} from "lucide-react";

function cn(...parts: Array<string | false | null | undefined>) {
  return parts.filter(Boolean).join(" ");
}

type QuizSet = {
  id: string;
  title: string;
  description: string | null;
  course_code: string | null;
  level: string | null;
  time_limit_minutes: number | null;
};

type QuizQuestion = {
  id: string;
  prompt: string;
  explanation: string | null;
  position: number | null;
};

type QuizOption = {
  id: string;
  question_id: string;
  text: string;
  is_correct: boolean;
  position: number | null;
};

function normalize(v: string) {
  return v.trim().replace(/\s+/g, " ");
}

function msToClock(ms: number) {
  const s = Math.max(0, Math.floor(ms / 1000));
  const mm = Math.floor(s / 60);
  const ss = s % 60;
  return `${String(mm).padStart(2, "0")}:${String(ss).padStart(2, "0")}`;
}

function safePushRecent(item: { id: string; title: string; course_code?: string; when?: string; href?: string }) {
  if (typeof window === "undefined") return;
  try {
    const raw = window.localStorage.getItem("jabuStudyRecent");
    const prev = raw ? (JSON.parse(raw) as any[]) : [];
    const next = [item, ...(Array.isArray(prev) ? prev : [])]
      .filter(Boolean)
      .filter((x, i, arr) => arr.findIndex((y) => y?.id === x?.id) === i)
      .slice(0, 12);
    window.localStorage.setItem("jabuStudyRecent", JSON.stringify(next));
  } catch {
    // ignore
  }
}

export default function PracticeTakeClient() {
  const router = useRouter();
  const params = useParams<{ setId: string }>();
  const sp = useSearchParams();
  const setId = String(params?.setId ?? "");
  const attemptFromUrl = String(sp.get("attempt") ?? "").trim();

  const [meta, setMeta] = useState<QuizSet | null>(null);
  const [questions, setQuestions] = useState<QuizQuestion[]>([]);
  const [optionsByQ, setOptionsByQ] = useState<Record<string, QuizOption[]>>({});
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState<string | null>(null);

  const [idx, setIdx] = useState(0);
  const [answers, setAnswers] = useState<Record<string, string>>({}); // qid -> optionId
  const [submitted, setSubmitted] = useState(false);
  const [flagged, setFlagged] = useState<Record<string, boolean>>({});

  const [attemptId, setAttemptId] = useState<string | null>(attemptFromUrl || null);
  const [startedAtMs, setStartedAtMs] = useState<number | null>(null);

  const [timeLeftMs, setTimeLeftMs] = useState<number | null>(null);
  const deadlineRef = useRef<number | null>(null);

  useEffect(() => {
    let cancelled = false;
    async function run() {
      setLoading(true);
      setErr(null);
      setSubmitted(false);
      setIdx(0);
      setAnswers({});
      setFlagged({});
      deadlineRef.current = null;
      setTimeLeftMs(null);

      try {
        if (!setId) throw new Error("Missing set id");

        const { data: setData, error: setErr } = await supabase
          .from("study_quiz_sets")
          .select("id,title,description,course_code,level,time_limit_minutes")
          .eq("id", setId)
          .maybeSingle();
        if (setErr) throw setErr;
        if (!setData) throw new Error("Practice set not found");

        // Load questions + options
        const { data: qData, error: qErr } = await supabase
          .from("study_quiz_questions")
          .select("id,prompt,explanation,position")
          .eq("set_id", setId)
          .order("position", { ascending: true });
        if (qErr) throw qErr;

        const qIds = (qData as any[] | null)?.map((q) => q.id) ?? [];
        let optData: any[] = [];
        if (qIds.length) {
          const { data: oData, error: oErr } = await supabase
            .from("study_quiz_options")
            .select("id,question_id,text,is_correct,position")
            .in("question_id", qIds)
            .order("position", { ascending: true });
          if (oErr) throw oErr;
          optData = (oData as any[]) ?? [];
        }

        const grouped: Record<string, QuizOption[]> = {};
        for (const o of optData) {
          const qid = String(o.question_id);
          if (!grouped[qid]) grouped[qid] = [];
          grouped[qid].push({
            id: String(o.id),
            question_id: qid,
            text: String(o.text ?? ""),
            is_correct: Boolean(o.is_correct),
            position: typeof o.position === "number" ? o.position : null,
          });
        }

        if (!cancelled) {
          setMeta(setData as any);
          setQuestions((qData as any) ?? []);
          setOptionsByQ(grouped);

          // 1) Restore or create an attempt
          const { data: auth } = await supabase.auth.getUser();
          const user = auth?.user;

          // Attempt restore (if ?attempt= exists)
          if (user && attemptFromUrl) {
            try {
              const { data: att, error: attErr } = await supabase
                .from("study_practice_attempts")
                .select("id,set_id,status,started_at")
                .eq("id", attemptFromUrl)
                .eq("user_id", user.id)
                .maybeSingle();
              if (!attErr && att?.id && String(att.set_id) === setId && String(att.status) === "in_progress") {
                setAttemptId(String(att.id));
                const st = new Date(String(att.started_at)).getTime();
                setStartedAtMs(Number.isFinite(st) ? st : Date.now());

                // load answers
                const { data: ans } = await supabase
                  .from("study_attempt_answers")
                  .select("question_id,selected_option_id")
                  .eq("attempt_id", String(att.id));
                const map: Record<string, string> = {};
                (ans ?? []).forEach((r: any) => {
                  if (r?.question_id && r?.selected_option_id) map[String(r.question_id)] = String(r.selected_option_id);
                });
                setAnswers(map);
              }
            } catch {
              // ignore
            }
          }

          // Create attempt if we don't have one
          if (user && !attemptFromUrl) {
            try {
              const startedIso = new Date().toISOString();
              const { data: created, error: cErr } = await supabase
                .from("study_practice_attempts")
                .insert({
                  user_id: user.id,
                  set_id: setId,
                  status: "in_progress",
                  started_at: startedIso,
                } as any)
                .select("id,started_at")
                .maybeSingle();
              if (!cErr && created?.id) {
                const id = String(created.id);
                setAttemptId(id);
                const st = new Date(String(created.started_at ?? startedIso)).getTime();
                setStartedAtMs(Number.isFinite(st) ? st : Date.now());
                // Update URL so user can resume.
                router.replace(`/study/practice/${encodeURIComponent(setId)}?attempt=${encodeURIComponent(id)}`);
              }
            } catch {
              // ignore if table doesn't exist
            }
          }

          // 2) Timer setup (deadline = started_at + limit)
          // Use a local base to avoid relying on async state updates.
          const mins = typeof (setData as any)?.time_limit_minutes === "number" ? (setData as any).time_limit_minutes : null;
          const base = typeof startedAtMs === "number" ? startedAtMs : Date.now();
          if (mins && mins > 0) {
            const deadline = base + mins * 60_000;
            deadlineRef.current = deadline;
            setTimeLeftMs(deadline - Date.now());
          }
        }
      } catch (e: any) {
        if (!cancelled) setErr(e?.message ?? "Failed to load practice set");
      } finally {
        if (!cancelled) setLoading(false);
      }
    }
    run();
    return () => {
      cancelled = true;
    };
  }, [setId, attemptFromUrl, router]);

  // Timer
  useEffect(() => {
    if (!deadlineRef.current) return;
    if (submitted) return;
    const t = setInterval(() => {
      const dl = deadlineRef.current;
      if (!dl) return;
      const left = dl - Date.now();
      setTimeLeftMs(left);
      if (left <= 0) {
        setSubmitted(true);
      }
    }, 250);
    return () => clearInterval(t);
  }, [submitted]);

  const current = questions[idx];
  const opts = current ? optionsByQ[current.id] ?? [] : [];

  const stats = useMemo(() => {
    const total = questions.length;
    const answered = Object.keys(answers).length;
    const flaggedCount = Object.values(flagged).filter(Boolean).length;

    let correct = 0;
    if (submitted) {
      for (const q of questions) {
        const chosen = answers[q.id];
        if (!chosen) continue;
        const o = (optionsByQ[q.id] ?? []).find((x) => x.id === chosen);
        if (o?.is_correct) correct += 1;
      }
    }
    return { total, answered, flaggedCount, correct };
  }, [questions, answers, flagged, submitted, optionsByQ]);

  function choose(qid: string, oid: string) {
    if (submitted) return;
    setAnswers((prev) => ({ ...prev, [qid]: oid }));

    // Persist answer (best-effort)
    (async () => {
      try {
        const { data: auth } = await supabase.auth.getUser();
        const user = auth?.user;
        if (!user || !attemptId) return;
        await supabase.from("study_attempt_answers").upsert(
          {
            attempt_id: attemptId,
            user_id: user.id,
            question_id: qid,
            selected_option_id: oid,
            updated_at: new Date().toISOString(),
          } as any,
          { onConflict: "attempt_id,question_id" }
        );
      } catch {
        // ignore
      }
    })();
  }

  function toggleFlag(qid: string) {
    setFlagged((prev) => ({ ...prev, [qid]: !prev[qid] }));
  }

  function submitNow() {
    setSubmitted(true);

    // Finalize attempt (best-effort)
    (async () => {
      try {
        const { data: auth } = await supabase.auth.getUser();
        const user = auth?.user;
        if (!user || !attemptId) return;

        const total = questions.length;
        let correct = 0;
        for (const q of questions) {
          const chosen = answers[q.id];
          if (!chosen) continue;
          const o = (optionsByQ[q.id] ?? []).find((x) => x.id === chosen);
          if (o?.is_correct) correct += 1;
        }

        const submittedIso = new Date().toISOString();
        // time spent
        let timeSpent = null as number | null;
        if (deadlineRef.current && meta?.time_limit_minutes) {
          const limitSec = meta.time_limit_minutes * 60;
          const left = typeof timeLeftMs === "number" ? Math.max(0, Math.floor(timeLeftMs / 1000)) : 0;
          timeSpent = Math.max(0, limitSec - left);
        } else if (startedAtMs) {
          timeSpent = Math.max(0, Math.floor((Date.now() - startedAtMs) / 1000));
        }

        await supabase
          .from("study_practice_attempts")
          .update({
            status: "submitted",
            submitted_at: submittedIso,
            score: correct,
            total_questions: total,
            time_spent_seconds: timeSpent,
          } as any)
          .eq("id", attemptId)
          .eq("user_id", user.id);

        // Update daily activity / streak (ignore if table missing)
        const activityDate = submittedIso.slice(0, 10);
        await supabase
          .from("study_daily_activity")
          .upsert(
            {
              user_id: user.id,
              activity_date: activityDate,
              did_practice: true,
              points: Math.max(1, correct),
              updated_at: submittedIso,
            } as any,
            { onConflict: "user_id,activity_date" }
          );

        // Push to local recent
        safePushRecent({
          id: `practice:${attemptId}`,
          title: meta?.title ?? "Practice",
          course_code: meta?.course_code ?? undefined,
          when: submittedIso,
          href: `/study/practice/${encodeURIComponent(setId)}?attempt=${encodeURIComponent(attemptId)}`,
        });
      } catch {
        // ignore
      }
    })();
  }

  function restart() {
    router.refresh();
  }

  if (loading) {
    return (
      <div className="mx-auto w-full max-w-3xl px-4 pb-24 pt-6">
        <div className="rounded-3xl border bg-white p-6 shadow-sm">
          <div className="flex items-center gap-2 text-sm font-semibold text-zinc-700">
            <Loader2 className="h-4 w-4 animate-spin" /> Loading practice…
          </div>
        </div>
      </div>
    );
  }

  if (err || !meta) {
    return (
      <div className="mx-auto w-full max-w-3xl px-4 pb-24 pt-6">
        <button
          type="button"
          onClick={() => router.back()}
          className="inline-flex items-center gap-2 rounded-2xl border bg-white px-4 py-2 text-sm font-semibold text-zinc-900 hover:bg-zinc-50"
        >
          <ArrowLeft className="h-4 w-4" /> Back
        </button>
        <div className="mt-4 rounded-3xl border bg-white p-6 shadow-sm">
          <p className="text-sm font-semibold text-zinc-900">Couldn’t open practice set</p>
          <p className="mt-1 text-sm text-zinc-600">{err ?? "Missing data"}</p>
          <Link
            href="/study/practice"
            className="mt-4 inline-flex items-center gap-2 rounded-2xl border bg-white px-4 py-2 text-sm font-semibold text-zinc-900 no-underline hover:bg-zinc-50"
          >
            Go to Practice Mode <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
      </div>
    );
  }

  const headerCode = normalize(String(meta.course_code ?? "")).toUpperCase();

  return (
    <div className="mx-auto w-full max-w-3xl px-4 pb-24 pt-6">
      <div className="flex items-center justify-between gap-3">
        <button
          type="button"
          onClick={() => router.back()}
          className="inline-flex items-center gap-2 rounded-2xl border bg-white px-4 py-2 text-sm font-semibold text-zinc-900 hover:bg-zinc-50"
        >
          <ArrowLeft className="h-4 w-4" /> Back
        </button>
        <div className="flex items-center gap-2">
          {typeof timeLeftMs === "number" ? (
            <div
              className={cn(
                "inline-flex items-center gap-2 rounded-full border px-3 py-2 text-xs font-extrabold",
                timeLeftMs <= 60_000 ? "border-rose-200 bg-rose-50 text-rose-700" : "border-zinc-200 bg-white text-zinc-800"
              )}
              title="Time left"
            >
              <Timer className="h-4 w-4" /> {msToClock(timeLeftMs)}
            </div>
          ) : null}
          <div className="rounded-full border bg-white px-3 py-2 text-xs font-extrabold text-zinc-800">
            {stats.answered}/{stats.total} answered
          </div>
          {stats.flaggedCount ? (
            <div className="rounded-full border bg-amber-50 px-3 py-2 text-xs font-extrabold text-amber-700">
              {stats.flaggedCount} flagged
            </div>
          ) : null}
        </div>
      </div>

      <div className="mt-6 rounded-3xl border bg-white p-4 shadow-sm">
        <div className="flex flex-wrap items-center gap-2">
          <p className="text-lg font-extrabold tracking-tight text-zinc-900">{normalize(String(meta.title ?? "Practice"))}</p>
          {headerCode ? (
            <Link
              href={`/study/courses/${encodeURIComponent(headerCode)}`}
              className="rounded-full border bg-white px-3 py-1.5 text-xs font-extrabold text-zinc-800 no-underline hover:bg-zinc-50"
            >
              {headerCode}
            </Link>
          ) : null}
          {meta.level ? (
            <span className="rounded-full border bg-white px-3 py-1.5 text-xs font-semibold text-zinc-700">{String(meta.level)}L</span>
          ) : null}
        </div>
        {meta.description ? <p className="mt-2 text-sm text-zinc-600">{normalize(meta.description)}</p> : null}
      </div>

      {questions.length === 0 ? (
        <div className="mt-4 rounded-3xl border bg-white p-6 shadow-sm">
          <p className="text-sm font-semibold text-zinc-900">No questions in this set yet</p>
          <p className="mt-1 text-sm text-zinc-600">
            Add questions in <code className="px-1">study_quiz_questions</code> and options in <code className="px-1">study_quiz_options</code>.
          </p>
        </div>
      ) : (
        <>
          <div className="mt-4 rounded-3xl border bg-white p-5 shadow-sm">
            <div className="flex items-start justify-between gap-3">
              <div className="min-w-0">
                <p className="text-xs font-extrabold text-zinc-600">Question {idx + 1} of {stats.total}</p>
                <p className="mt-2 whitespace-pre-wrap text-base font-semibold text-zinc-900">{normalize(String(current?.prompt ?? ""))}</p>
              </div>
              <button
                type="button"
                onClick={() => toggleFlag(current.id)}
                className={cn(
                  "inline-flex items-center gap-2 rounded-2xl border px-3 py-2 text-xs font-extrabold",
                  flagged[current.id] ? "border-amber-200 bg-amber-50 text-amber-700" : "border-zinc-200 bg-white text-zinc-800 hover:bg-zinc-50"
                )}
                title="Flag this question"
              >
                <Flag className="h-4 w-4" /> {flagged[current.id] ? "Flagged" : "Flag"}
              </button>
            </div>

            <div className="mt-4 grid gap-2">
              {opts.map((o, i) => {
                const chosen = answers[current.id] === o.id;
                const show = submitted;
                const correct = o.is_correct;

                const leftIcon = show ? (correct ? <CheckCircle2 className="h-5 w-5" /> : <XCircle className="h-5 w-5" />) : <Circle className="h-5 w-5" />;

                return (
                  <button
                    key={o.id}
                    type="button"
                    onClick={() => choose(current.id, o.id)}
                    className={cn(
                      "flex w-full items-start gap-3 rounded-2xl border px-4 py-3 text-left text-sm font-semibold transition",
                      chosen ? "border-zinc-900 bg-zinc-900 text-white" : "border-zinc-200 bg-white text-zinc-900 hover:bg-zinc-50",
                      show && correct ? "border-emerald-200 bg-emerald-50 text-emerald-800" : "",
                      show && chosen && !correct ? "border-rose-200 bg-rose-50 text-rose-800" : ""
                    )}
                    disabled={submitted}
                  >
                    <span className={cn("mt-0.5", show && correct ? "text-emerald-700" : "", show && chosen && !correct ? "text-rose-700" : "")}>{leftIcon}</span>
                    <span className="min-w-0 whitespace-pre-wrap">{String.fromCharCode(65 + i)}. {normalize(String(o.text ?? ""))}</span>
                  </button>
                );
              })}
            </div>

            {submitted ? (
              <div className="mt-4 rounded-2xl border bg-zinc-50 p-4">
                <p className="text-sm font-extrabold text-zinc-900">Explanation</p>
                <p className="mt-1 whitespace-pre-wrap text-sm font-semibold text-zinc-700">
                  {normalize(String(current?.explanation ?? "No explanation provided."))}
                </p>
              </div>
            ) : null}
          </div>

          <div className="mt-4 flex items-center justify-between gap-3">
            <button
              type="button"
              onClick={() => setIdx((p) => Math.max(0, p - 1))}
              className={cn(
                "inline-flex items-center gap-2 rounded-2xl border bg-white px-4 py-3 text-sm font-semibold text-zinc-900 hover:bg-zinc-50",
                idx === 0 ? "opacity-60" : ""
              )}
              disabled={idx === 0}
            >
              <ArrowLeft className="h-4 w-4" /> Prev
            </button>

            {!submitted ? (
              <button
                type="button"
                onClick={submitNow}
                className="inline-flex items-center gap-2 rounded-2xl border border-zinc-900 bg-zinc-900 px-4 py-3 text-sm font-semibold text-white hover:bg-zinc-800"
              >
                Submit <ArrowRight className="h-4 w-4" />
              </button>
            ) : (
              <div className="text-right">
                <p className="text-sm font-extrabold text-zinc-900">Score: {stats.correct}/{stats.total}</p>
                <p className="mt-0.5 text-xs font-semibold text-zinc-600">
                  {Math.round((stats.correct / Math.max(1, stats.total)) * 100)}%
                </p>
              </div>
            )}

            <button
              type="button"
              onClick={() => setIdx((p) => Math.min(stats.total - 1, p + 1))}
              className={cn(
                "inline-flex items-center gap-2 rounded-2xl border bg-white px-4 py-3 text-sm font-semibold text-zinc-900 hover:bg-zinc-50",
                idx >= stats.total - 1 ? "opacity-60" : ""
              )}
              disabled={idx >= stats.total - 1}
            >
              Next <ArrowRight className="h-4 w-4" />
            </button>
          </div>

          {submitted ? (
            <div className="mt-4 grid gap-2 rounded-3xl border bg-white p-4 shadow-sm">
              <p className="text-sm font-extrabold text-zinc-900">Review</p>
              <div className="flex flex-wrap gap-2">
                {questions.map((q, i) => {
                  const chosen = answers[q.id];
                  const o = chosen ? (optionsByQ[q.id] ?? []).find((x) => x.id === chosen) : null;
                  const ok = Boolean(o?.is_correct);
                  return (
                    <button
                      key={q.id}
                      type="button"
                      onClick={() => setIdx(i)}
                      className={cn(
                        "h-10 w-10 rounded-2xl border text-sm font-extrabold",
                        i === idx ? "border-zinc-900 bg-zinc-900 text-white" : "bg-white text-zinc-900 hover:bg-zinc-50",
                        ok ? "border-emerald-200 bg-emerald-50 text-emerald-800" : "",
                        chosen && !ok ? "border-rose-200 bg-rose-50 text-rose-800" : "",
                        !chosen ? "border-zinc-200 bg-white text-zinc-700" : ""
                      )}
                      title={ok ? "Correct" : chosen ? "Wrong" : "Unanswered"}
                    >
                      {i + 1}
                    </button>
                  );
                })}
              </div>

              <div className="mt-2 flex flex-wrap items-center gap-2">
                <button
                  type="button"
                  onClick={restart}
                  className="inline-flex items-center gap-2 rounded-2xl border bg-white px-4 py-2 text-sm font-semibold text-zinc-900 hover:bg-zinc-50"
                >
                  <RefreshCcw className="h-4 w-4" /> Restart
                </button>

                {attemptId ? (
                  <Link
                    href={`/study/history/${encodeURIComponent(attemptId)}`}
                    className="inline-flex items-center gap-2 rounded-2xl border border-zinc-900 bg-zinc-900 px-4 py-2 text-sm font-semibold text-white no-underline hover:bg-zinc-800"
                  >
                    Review mistakes <ArrowRight className="h-4 w-4" />
                  </Link>
                ) : null}

                <Link
                  href={headerCode ? `/study/practice?course=${encodeURIComponent(headerCode)}` : "/study/practice"}
                  className="inline-flex items-center gap-2 rounded-2xl border bg-white px-4 py-2 text-sm font-semibold text-zinc-900 no-underline hover:bg-zinc-50"
                >
                  More sets <ArrowRight className="h-4 w-4" />
                </Link>
              </div>
            </div>
          ) : null}
        </>
      )}
    </div>
  );
}
