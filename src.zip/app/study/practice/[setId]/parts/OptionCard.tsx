"use client";

import { CheckCircle2, Circle } from "lucide-react";
import { cn, normalize } from "../usePracticeEngine";

export default function OptionCard({
  label,
  text,
  chosen,
  disabled,
  onClick,
  rightHint,
}: {
  label: string;
  text: string;
  chosen: boolean;
  disabled?: boolean;
  onClick: () => void;
  rightHint?: React.ReactNode;
}) {
  return (
    <button
      type="button"
      disabled={disabled}
      onClick={onClick}
      className={cn(
        "flex w-full items-start gap-3 rounded-2xl border px-4 py-3 text-left text-sm font-semibold transition",
        "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background",
        chosen
          ? "border-border bg-secondary text-foreground"
          : "border-border bg-background text-foreground hover:bg-secondary/50",
        disabled ? "opacity-70" : ""
      )}
      aria-label={`Option ${label}`}
    >
      <div className="mt-0.5 flex items-center gap-2">
        <span className="grid h-7 w-7 place-items-center rounded-xl border border-border bg-background text-[11px] font-extrabold text-muted-foreground">
          {label}
        </span>
        <span className="text-muted-foreground">{chosen ? <CheckCircle2 className="h-5 w-5" /> : <Circle className="h-5 w-5" />}</span>
      </div>

      <span className="min-w-0 flex-1 whitespace-pre-wrap">{normalize(text)}</span>

      {rightHint ? <span className="ml-2 shrink-0">{rightHint}</span> : null}
    </button>
  );
}
