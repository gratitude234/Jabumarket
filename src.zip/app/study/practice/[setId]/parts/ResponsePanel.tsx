"use client";

import { useEffect, useMemo, useState } from "react";
import { CheckCircle2, Info, XCircle } from "lucide-react";
import { Card } from "@/app/study/_components/StudyUI";
import { cn, normalize, QuizOption } from "../usePracticeEngine";

export default function ResponsePanel({
  explanation,
  chosenOptionId,
  options,
  autoReveal,
  onToggleAutoReveal,
}: {
  explanation: string | null;
  chosenOptionId: string | null;
  options: QuizOption[];
  autoReveal: boolean;
  onToggleAutoReveal: (v: boolean) => void;
}) {
  const chosen = useMemo(
    () => (chosenOptionId ? options.find((o) => o.id === chosenOptionId) ?? null : null),
    [chosenOptionId, options]
  );
  const correct = useMemo(() => options.find((o) => o.is_correct) ?? null, [options]);

  const [open, setOpen] = useState(false);

  useEffect(() => {
    // If autoReveal is on, show panel when user answers.
    if (autoReveal && chosenOptionId) setOpen(true);
  }, [autoReveal, chosenOptionId]);

  const state = !chosen
    ? "idle"
    : chosen.is_correct
    ? "correct"
    : "wrong";

  return (
    <Card className="rounded-3xl p-4">
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <p className="text-sm font-extrabold text-foreground">Instant feedback</p>
          <p className="mt-1 text-xs text-muted-foreground">
            Like Gemini-style quizzes: pick an option, get feedback, then move on.
          </p>
        </div>

        <button
          type="button"
          onClick={() => onToggleAutoReveal(!autoReveal)}
          className={cn(
            "shrink-0 inline-flex items-center gap-2 rounded-2xl border px-3 py-2 text-xs font-extrabold",
            "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-card",
            autoReveal
              ? "border-border bg-secondary text-foreground"
              : "border-border/60 bg-background text-muted-foreground hover:bg-secondary/50 hover:text-foreground"
          )}
          aria-pressed={autoReveal}
        >
          Auto
        </button>
      </div>

      <div className="mt-4 rounded-2xl border border-border bg-background p-3">
        <div className="flex items-start justify-between gap-3">
          <div className="min-w-0">
            {state === "idle" ? (
              <p className="text-sm font-semibold text-muted-foreground">
                Choose an option to see feedback.
              </p>
            ) : state === "correct" ? (
              <p className="inline-flex items-center gap-2 text-sm font-extrabold text-foreground">
                <CheckCircle2 className="h-4 w-4" /> Correct
              </p>
            ) : (
              <p className="inline-flex items-center gap-2 text-sm font-extrabold text-foreground">
                <XCircle className="h-4 w-4" /> Not quite
              </p>
            )}

            {chosen ? (
              <p className="mt-2 text-xs text-muted-foreground">
                Your answer: <span className="font-semibold text-foreground">{normalize(chosen.text)}</span>
              </p>
            ) : null}

            {chosen && correct ? (
              <p className="mt-1 text-xs text-muted-foreground">
                Correct answer: <span className="font-semibold text-foreground">{normalize(correct.text)}</span>
              </p>
            ) : null}
          </div>

          <button
            type="button"
            onClick={() => setOpen((v) => !v)}
            disabled={!chosenOptionId}
            className={cn(
              "shrink-0 inline-flex items-center gap-2 rounded-2xl border px-3 py-2 text-xs font-extrabold",
              "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-card",
              chosenOptionId
                ? "border-border bg-background text-foreground hover:bg-secondary/50"
                : "border-border/50 bg-background text-muted-foreground opacity-60"
            )}
          >
            <Info className="h-4 w-4" /> {open ? "Hide" : "Explain"}
          </button>
        </div>

        {open ? (
          <div className="mt-3 rounded-2xl border border-border bg-card p-3">
            <p className="text-xs font-extrabold text-muted-foreground">EXPLANATION</p>
            <p className="mt-1 text-sm text-muted-foreground">
              {explanation ? normalize(explanation) : "No explanation provided for this question."}
            </p>
          </div>
        ) : null}
      </div>
    </Card>
  );
}
