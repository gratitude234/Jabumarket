"use client";

import { useEffect, useMemo, useState } from "react";
import { usePathname, useRouter, useSearchParams } from "next/navigation";
import { ArrowLeft, Timer, Sparkles } from "lucide-react";
import { cn, msToClock } from "../usePracticeEngine";

export type PracticeMode = "exam" | "interactive";

function buildHref(path: string, params: Record<string, string | null | undefined>) {
  const sp = new URLSearchParams();
  Object.entries(params).forEach(([k, v]) => {
    const s = (v ?? "").toString().trim();
    if (!s) return;
    sp.set(k, s);
  });
  const qs = sp.toString();
  return qs ? `${path}?${qs}` : path;
}

export default function TopBar({
  timeLeftMs,
  answered,
  total,
  flaggedCount,
  disabled,
  defaultMode,
}: {
  timeLeftMs: number | null;
  answered: number;
  total: number;
  flaggedCount: number;
  disabled?: boolean;
  defaultMode: PracticeMode;
}) {
  const router = useRouter();
  const pathname = usePathname();
  const sp = useSearchParams();

  const attempt = sp.get("attempt") ?? "";

  const modeParam = (sp.get("mode") ?? "") as PracticeMode | "";
  const initialMode = (modeParam === "exam" || modeParam === "interactive" ? modeParam : "") || defaultMode;

  const [mode, setMode] = useState<PracticeMode>(initialMode);

  // keep state synced with URL changes
  useEffect(() => {
    const m = (sp.get("mode") ?? "") as PracticeMode | "";
    const next = (m === "exam" || m === "interactive" ? m : "") || defaultMode;
    setMode(next);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [sp, defaultMode]);

  const modeLabel = useMemo(() => (mode === "interactive" ? "Interactive" : "Exam"), [mode]);

  function switchMode(next: PracticeMode) {
    setMode(next);
    // persist preference
    try {
      window.localStorage.setItem("jabu:practiceMode", next);
    } catch {
      // ignore
    }
    router.replace(
      buildHref(pathname, {
        attempt: attempt || null,
        mode: next,
      })
    );
  }

  return (
    <div className="flex items-center justify-between gap-3">
      <button
        type="button"
        onClick={() => router.back()}
        className={cn(
          "inline-flex items-center gap-2 rounded-2xl border border-border bg-background px-4 py-2 text-sm font-extrabold text-foreground",
          "hover:bg-secondary/50 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
        )}
        aria-label="Go back"
      >
        <ArrowLeft className="h-4 w-4" /> Back
      </button>

      <div className="flex items-center gap-2">
        {typeof timeLeftMs === "number" ? (
          <div
            className={cn(
              "inline-flex items-center gap-2 rounded-full border px-3 py-2 text-xs font-extrabold",
              timeLeftMs <= 60_000
                ? "border-amber-300/40 bg-amber-100/40 text-foreground dark:bg-amber-950/30"
                : "border-border bg-background text-foreground"
            )}
            title="Time left"
          >
            <Timer className="h-4 w-4" /> {msToClock(timeLeftMs)}
          </div>
        ) : null}

        <div className="rounded-full border border-border bg-background px-3 py-2 text-xs font-extrabold text-foreground">
          {answered}/{total} answered
        </div>

        {flaggedCount ? (
          <div className="rounded-full border border-border bg-secondary px-3 py-2 text-xs font-extrabold text-foreground">
            {flaggedCount} flagged
          </div>
        ) : null}

        <div className="hidden sm:flex items-center gap-2 rounded-full border border-border bg-background px-2 py-1.5">
          <button
            type="button"
            disabled={disabled}
            onClick={() => switchMode("interactive")}
            className={cn(
              "inline-flex items-center gap-1 rounded-full px-3 py-1.5 text-xs font-extrabold transition",
              mode === "interactive" ? "bg-secondary text-foreground" : "text-muted-foreground hover:bg-secondary/50",
              disabled ? "opacity-60" : ""
            )}
          >
            <Sparkles className="h-3.5 w-3.5" /> Interactive
          </button>
          <button
            type="button"
            disabled={disabled}
            onClick={() => switchMode("exam")}
            className={cn(
              "inline-flex items-center gap-1 rounded-full px-3 py-1.5 text-xs font-extrabold transition",
              mode === "exam" ? "bg-secondary text-foreground" : "text-muted-foreground hover:bg-secondary/50",
              disabled ? "opacity-60" : ""
            )}
          >
            Exam
          </button>
        </div>

        {/* Mobile compact toggle */}
        <button
          type="button"
          disabled={disabled}
          onClick={() => switchMode(mode === "interactive" ? "exam" : "interactive")}
          className={cn(
            "sm:hidden inline-flex items-center gap-2 rounded-2xl border border-border bg-background px-3 py-2 text-xs font-extrabold text-foreground",
            "hover:bg-secondary/50 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2",
            disabled ? "opacity-60" : ""
          )}
          aria-label="Switch mode"
          title="Switch mode"
        >
          <Sparkles className="h-4 w-4" /> {modeLabel}
        </button>
      </div>
    </div>
  );
}
