// app/study/leaderboard/page.tsx

import LeaderboardClient from "./LeaderboardClient";

export const dynamic = "force-dynamic";

export default function LeaderboardPage() {
  return <LeaderboardClient />;
}
